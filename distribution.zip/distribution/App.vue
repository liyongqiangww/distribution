<script>
    import AES from './common/aes.js'
    import {
        mapState,
        mapMutations
    } from 'vuex'
	export default {
        methods: {
            ...mapMutations(['login'])
        },
        onLaunch: function() {
            //更新登陆状态
            // uni.getStorage({
            //     key: 'userInfo',
            //     success: (res) => {
            //         // 解密
            //         let decrypt = JSON.parse(AES.AES.decrypt(res.data,'Ow8bd11KeZS=','123456'))
            //         this.login(decrypt);    
            //     }
            // });
            // 小程序版本更新启动--Start
			//#ifdef MP-WEIXIN
            const updateManager = uni.getUpdateManager();
            updateManager.onCheckForUpdate(function(res) {
                // 请求完新版本信息的回调
                if (res.hasUpdate) {
                    updateManager.onUpdateReady(function(res2) {
                        updateManager.applyUpdate();
                    });
                }
            });
            updateManager.onUpdateFailed(function(res) {
                // 新的版本下载失败
                uni.showModal({
                    title: '提示',
                    content: '检查到有新版本，但下载失败，请检查网络设置',
                    success(res) {
                        if (res.confirm) {
                            // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                            updateManager.applyUpdate();
                        }
                    }
                });
            });
			//#endif
            // 小程序版本更新启动--End
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style lang="scss">
    /* 暂无~ */
    .nodata {
        width: 100%;
        box-sizing: border-box;
        padding-top: 30upx;
        text-align: center;
        color: #979797;
        font-size: 30upx;
    }
    .btn:active {
    	transform: translate(2upx, 2upx);
    }
</style>