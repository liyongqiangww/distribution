import Vue from 'vue'
import App from './App'
import Http from './common/http.js'

import store from './store'

Vue.prototype.$store = store
Vue.prototype.$api = Http;

// 图片访问域名
Vue.prototype.$imgUrl = 'http://39.107.114.113:9527/tuokebang-service'
// 图片上传域名
Vue.prototype.$fileUrl = 'http://39.107.114.113:9527/tuokebang-service'

//常用组件
import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
Vue.component('uni-load-more', uniLoadMore);

App.mpType = 'app'

const app = new Vue({
    ...App
})
app.$mount()
