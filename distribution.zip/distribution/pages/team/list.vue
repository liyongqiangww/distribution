<template>
	<view>
		<view class="team-list">
			<view class="goodList">
			    <view class="list" v-for="(item,index) in 3" :key="index" >
					<!-- #939393  未认证 -->
					<view class="approve">
						已认证
					</view>
			        <view class="img">
			            <image class="avator" src="/static/images/test/avator.png" mode="aspectFill"></image>
						<view class="grade">
							<image class="v" src="/static/images/grade.png"></image>
							<text class="txt">黄金</text>
						</view>
			        </view>
			        <view class="titleName">
			            亚历山大
			        </view>
			        <view class="time">
			            2021 · 11 · 04
			        </view>
					<view class="good-type" v-for="(item,index) in 2" :key="index">
						<view class="left">
							陶特拉新地推版
						</view>
						<view class="num">
							x15
						</view>
					</view>
			    </view>
			</view>
		</view>
		<uni-load-more iconType="snow" :status="status" v-if="showTip"/>
		<view class="nodata" v-else>
		    暂无数据
		</view>
	</view>
</template>

<script>
	export default {
		data () {
			return {
				showTip:true,
				status: 'loading',//数据加载的状态(more：加载前,loading:加载中,noMore:没有更多)
				page:1,//上拉加载
				list:[],
			}
		},
		methods:{
			getList(page){
			    this.$api.sendRequest({
			    	url: '/api/mine/mine_bm',
			    	data: {
			            page:page,
			            uid:this.userInfo.id
			    	},
			    	success: res => {
			    		if(res.code && res.code == 200){
			    		   this.list = this.list.concat(res.result)
			    		   if(this.list.length == 0) {
			    		       this.showTip = false
			    		       return ;
			    		   }
			    		   if (res.result.length<15) {
			    		       this.status = 'noMore'
			    		   }else{
			    		       this.status = 'more'
			    		   }
			    		}
			    	}
			    });
			}
		}
	}
</script>

<style lang="scss" scoped>
	@mixin text-over {
	    overflow: hidden;
	    text-overflow: ellipsis;
	    white-space: nowrap;
	}
	.team-list {
		width: 100%;
		box-sizing: border-box;
		padding: 0 21upx;
		margin-top:30upx;
		.goodList {
		    width: 100%;
		    box-sizing: border-box;
		    column-count:2;
		    column-gap: 20rpx;
		    -webkit-column-width: auto;
		    column-width: auto;
		    background-color: #fff;
		    .list {
				position: relative;
		        width: 100%;
		        -moz-page-break-inside: avoid;
		        -webkit-column-break-inside: avoid;
		        break-inside: avoid;
		        box-sizing: border-box;
		        margin-bottom: 30upx;
				padding: 58upx 16upx 30upx;
		        background:#fff;
		        border: 2upx solid #E3E3E3;
		        box-shadow: 0upx 0upx 15upx #E3E3E3;
		        border-radius: 10upx;
				.approve {
					position: absolute;
					left: 0;
					top:0;
					width: 110upx;
					height: 45upx;
					line-height: 45upx;
					text-align: center;
					background: #EB0000;
					font-size: 22upx;
					font-weight: 400;
					color: #FFFFFF;
					border-radius: 10upx 0px 10upx 0px;
					z-index: 1;
				}
		        .img {
					position: relative;
		            width: 160upx;
					height: 160upx;
					overflow: hidden;
					border: 10upx solid #F2C719;
					border-radius: 50%;
					margin:auto;
		            .avator {
						display: block;
		                width: 100%;
						height: 100%;
		                border-radius: 50%;
		            }
					.grade {
						position: absolute;
						bottom: 0upx;
						width: 100%;
						height: 60upx;
						line-height: 40upx;
						background: rgba($color: #000000, $alpha: .2);
						// opacity: 0.2;
						z-index: 1;
						text-align: center;
						.v {
							width: 20upx;
							height: 20upx;
							margin-right: 10upx;
							vertical-align: middle;
						}
						.txt {
							font-size: 22upx;
							font-weight: 400;
							color: #FFFFFF;
							vertical-align: middle;
						}
					}
		        }
		        .titleName {
		            width: 100%;
		            box-sizing: border-box;
					@include text-over;
		            margin-top: 20upx;
					text-align: center;
		            font-size:29upx;
		            color:rgba(51,51,51,1);
		        }
		        .time {
					text-align: center;
					margin-top: 30upx;
					font-size: 22upx;
					font-weight: 400;
					color: #333333;
		        }
				.good-type {
					display: flex;
					justify-content: space-between;
					align-items: center;
					width: 100%;
					margin-top: 20upx;
					padding-bottom:10upx;
					border-bottom: 2upx solid #DDDDDD;
					view {
						font-size: 22upx;
						font-weight: 400;
						color: #939393;
					}
					.left {
						width: 70%;
						@include text-over;
					}
					.right {
						
					}
				}
		    }
		}
	}
</style>
