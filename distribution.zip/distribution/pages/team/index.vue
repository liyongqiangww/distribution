<template>
	<view>
		<view class="header">
			<image class="teamImg" src="/static/images/test/team.png" mode="widthFix"></image>
		</view>
		<view class="cater">
			<view class="cater-item">
				<view class="num">
					1008
				</view>
				<view class="title">
					团队总人数
				</view>
			</view>
			<view class="line"></view>
			<view class="cater-item">
				<view class="num">
					<text class="icon">￥</text>1008
				</view>
				<view class="title">
					培训费
				</view>
			</view>
		</view>
		<view class="team-list">
			<!--  @tap="toMore" -->
			<view class="head">
				<text class="title">团队列表</text>
				<!-- <text class="more">更多></text> -->
			</view>
			<view>
				<view class="goodList">
				    <view class="list" v-for="(item,index) in list" :key="index" >
						<view class="approve" :class="authentication?'':'isnone'">
							已认证
						</view>
						<view class="brokerage" @tap="toJump(item)">
							佣金比例
						</view>
				        <view class="img">
				            <image class="avator" src="/static/images/test/avator.png" mode="aspectFill"></image>
							<view class="grade" v-if="item.role">
								<image class="v" src="/static/images/grade.png"></image>
								<text class="txt">{{item.role.roleName}}</text>
							</view>
				        </view>
				        <view class="titleName">
				            {{item.deptName}}
				        </view>
				        <view class="time">
				            {{item.createTime}}
				        </view>
						<view class="good-type" v-for="(row,rindex) in item.list" :key="rindex">
							<view class="left" v-if="row.name">
								{{row.name}}
							</view>
							<view class="num" v-if="row.order">
								x{{row.order}}
							</view>
						</view>
				    </view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
	    mapState,
	    mapMutations
	} from 'vuex'
	export default {
		data () {
			return {
				list:[]
			}
		},
		computed:{
		    ...mapState(['hasLogin','userInfo'])
		},
		onLoad() {
			this.getList()
		},
		methods: {
			toJump (item) {
				uni.navigateTo({
					url:'./brokerage?item='+ encodeURIComponent(JSON.stringify(item))
				})
			},
			toMore () {
				uni.navigateTo({
					url:'list'
				})
			},
			getList (page) {
				let that = this
			    this.$api.sendRequest({
					method:'GET',
			    	url: '/dept/getOurList',
					header:{
						// 'Content-Type':'application/json',
						'Authentication':that.userInfo.token
					},
					data:{
						deptId:that.userInfo.user.inviteCode
					},
			    	success: res => {
						console.log(res)
						this.list = res.rows || []
			    	}
			    });
			},
		}
	}
</script>

<style lang="scss" scoped>
	@mixin text-over {
	    overflow: hidden;
	    text-overflow: ellipsis;
	    white-space: nowrap;
	}
	.header {
		overflow: hidden;
		width: 100%;
		height: 380upx;
		.teamImg {
			display: block;
			width: 100%;
			height: 100%;
		}
	}
	.cater {
		position: relative;
		top: -50upx;
		z-index: 10;
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 694upx;
		height: 173upx;
		margin: auto;
		background: #FFFFFF;
		border-radius: 10upx;
		border: 2upx solid #E2E2E2;
		box-shadow: 3upx 0upx 15upx #E2E2E2;
		.cater-item {
			width: calc(50% - 25upx);
			text-align: center;
			.num {
				font-size: 50upx;
				font-weight: 400;
				color: #EB0000;
				.icon {
					font-size: 29upx;
				}
			}
			.title {
				margin-top: 10upx;
				font-size: 22upx;
				font-weight: 400;
				color: #939393;
			}
		}
		.line {
			width: 1upx;
			height: 125upx;
			margin: 0 10upx;
			background: #DDDDDD;
			border-radius: 1upx;
		}
	}
	.team-list {
		width: 100%;
		box-sizing: border-box;
		padding: 0 21upx;
		margin-top:-10upx;
		.head {
			display: flex;
			justify-content: space-between;
			align-items: center;
			width: 100%;
			height: 70upx;
			box-sizing: border-box;
			padding: 0 15upx;
			background: #F6F6F6;
			.title {
				font-size: 26upx;
				font-weight: 400;
				color: #151515;
			}
			.more {
				font-size: 22upx;
				font-weight: 400;
				color: #939393;
			}
		}
		.goodList {
		    width: 100%;
		    box-sizing: border-box;
		    column-count:2;
		    column-gap: 20rpx;
		    -webkit-column-width: auto;
		    column-width: auto;
			margin-top: 45upx;
		    background-color: #fff;
		    .list {
				position: relative;
		        width: 100%;
		        -moz-page-break-inside: avoid;
		        -webkit-column-break-inside: avoid;
		        break-inside: avoid;
		        box-sizing: border-box;
		        margin-bottom: 30upx;
				padding: 58upx 16upx 30upx;
		        background:#fff;
		        border: 2upx solid #E3E3E3;
		        box-shadow: 0upx 0upx 15upx #E3E3E3;
		        border-radius: 10upx;
				.approve {
					position: absolute;
					left: 0;
					top:0;
					width: 110upx;
					height: 45upx;
					line-height: 45upx;
					text-align: center;
					background: #EB0000;
					font-size: 22upx;
					font-weight: 400;
					color: #FFFFFF;
					border-radius: 10upx 0px 10upx 0px;
					z-index: 1;
				}
				.brokerage {
					position: absolute;
					top: 0upx;
					right: 0upx;
					font-size: 28upx;
					color: #FFF;
					padding: 5upx 10upx;
					border-radius: 0upx 10upx 0upx 10upx;
					background-color: #EB0000;
				}
				.isnone {
					background-color: #ccc;
				}
		        .img {
					position: relative;
		            width: 160upx;
					height: 160upx;
					overflow: hidden;
					border: 10upx solid #F2C719;
					border-radius: 50%;
					margin:auto;
		            .avator {
						display: block;
		                width: 100%;
						height: 100%;
		                border-radius: 50%;
		            }
					.grade {
						position: absolute;
						bottom: 0upx;
						width: 100%;
						height: 60upx;
						line-height: 40upx;
						background: rgba($color: #000000, $alpha:.2);
						z-index: 1;
						text-align: center;
						.v {
							width: 20upx;
							height: 20upx;
							margin-right: 10upx;
							vertical-align: middle;
						}
						.txt {
							font-size: 22upx;
							font-weight: 400;
							color: #FFFFFF;
							vertical-align: middle;
						}
					}
		        }
		        .titleName {
		            width: 100%;
		            box-sizing: border-box;
					@include text-over;
		            margin-top: 20upx;
					text-align: center;
		            font-size:29upx;
		            color:rgba(51,51,51,1);
		        }
		        .time {
					text-align: center;
					margin-top: 30upx;
					font-size: 22upx;
					font-weight: 400;
					color: #333333;
		        }
				.good-type {
					display: flex;
					justify-content: space-between;
					align-items: center;
					width: 100%;
					margin-top: 20upx;
					padding-bottom:10upx;
					border-bottom: 2upx solid #DDDDDD;
					view {
						font-size: 22upx;
						font-weight: 400;
						color: #939393;
					}
					.left {
						width: 70%;
						@include text-over;
					}
					.right {
						
					}
				}
		    }
		}
	}
</style>
