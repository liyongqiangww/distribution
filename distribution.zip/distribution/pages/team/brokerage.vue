<template>
    <view class="container">
		<view class="tip">
			注意：请输入0~30的整数
		</view>
		<view class="input">
			<input class="uniInput" type="number" v-model="brokerage" placeholder="请输入佣金比例" placeholder-style="font-size:30upx;color: #939393;"/>
		</view>
		<view class="save btn" @tap="save">
			确认修改
		</view>
    </view>
</template>
<script>
    import {
        mapState,
        mapMutations
    } from 'vuex'
	import aesEncrypt from '@/common/aesEncrypt.js'
    export default {
        data() {
            return {
				brokerage:5,
				deptItem:{}
            };
        },
		computed:{
		    ...mapState(['hasLogin','userInfo'])
		},
        onLoad(option) {
			this.deptItem = JSON.parse(decodeURIComponent(option.item));
        },
        methods: {
			save () {
				let that = this;
				if(!that.brokerage){
				    uni.showToast({ title: '请输入佣金比例', icon: "none" });
				    return false;
				}
				uni.showLoading()
				that.$api.sendRequest({
				    url: '/dept',
					method:'PUT',
					header:{
						'Content-Type':'application/json',
						'Authentication':that.userInfo.token
					},
				    data: {
						brokerage:that.brokerage/100,
						deptId:that.deptItem.deptId
					},
				    success: res => {
				        uni.hideLoading()
						if(res.code && res.code==200){
							uni.redirectTo({
								url:'/pages/team/index'
							})
						}else{
							uni.showModal({
								showCancel:false,
							    content:res.message
							})
						}
				    }
				});
			},
        }
    }
</script>

<style lang="scss" scoped>
	.container {
		padding-top: 30upx;
	}
	.tip {
		width: 555upx;
		box-sizing: border-box;
		padding: 30upx 15upx 14upx;
		margin: auto;
		font-size: 28upx;
		color: #EB0000;
		border-bottom: 2upx solid #DDDDDD;
	}
   .input {
	    position: relative;
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 555upx;
		box-sizing: border-box;
		padding: 0 15upx 14upx;
		margin: 40upx auto;
		border-bottom: 2upx solid #DDDDDD;
		.img {
			display: block;
			width: 29upx;
			height: 46upx;
		}
		.xmg {
			display: block;
			width: 47upx;
			height: 43upx;
		}
		.uniInput {
			width: calc(100% - 60upx);
			font-size: 30upx;
			color: #333;
		}
		.vscode {
			position: absolute;
			right: 0;
			top: 0;
			width: 169upx;
			height: 45upx;
			line-height: 45upx;
			text-align: center;
			font-size: 22upx;
			font-weight: 400;
			color: #FFFFFF;
			background: #EB0000;
			border-radius: 10upx;
		}
   }
   .save {
		width: 555upx;
		height: 90upx;
		line-height: 90upx;
		text-align: center;
		margin:60upx auto 0;
		font-size: 38upx;
		font-weight: 400;
		color: #FFFFFF;
		background: #EB0000;
		border-radius: 10upx;
   }
</style>

