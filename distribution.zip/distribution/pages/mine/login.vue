<template>
    <view class="container">
        <view class="logo">
        	<image src="/static/images/logo.png"></image>
        </view>
		<view class="input">
			<image class="img" src="/static/images/mine/phone.png"></image>
			<input class="uniInput" v-model="phone" placeholder="请输入手机号" placeholder-style="font-size:30upx;color: #939393;"/>
		</view>
		<view class="input">
			<image class="img" src="/static/images/code.png"></image>
			<input class="uniInput" v-model="verCode" maxlength="10" placeholder="请输入验证码" placeholder-style="font-size:30upx;color: #939393;"/>
			<view class="vscode" @tap="handleCode">
				{{acquire}}
			</view>
		</view>
		<view class="save btn" @tap="phoneLogin">
			登录
		</view>
		<view class="r_l">
			<text @tap="toJump('register')">注册</text>
			<text @tap="toJump('pass')">密码登录</text>
		</view>
    </view>
</template>
<script>
    import {
        mapMutations
    } from 'vuex';
    export default {
        data() {
            return {
                getCodeisWaiting:false,
                acquire:'验证码',//获取验证码
                phone:'',
                verCode:''
            };
        },
        onLoad() {
			uni.clearStorage();
        },
        methods: {
            ...mapMutations(['login']),
            toJump (url) {
				uni.navigateTo({
					url:url
				})
			},
			phoneLogin () {
			    let phones=/^1(3|4|5|6|7|8|9)\d{9}$/;
			    if(!phones.test(this.phone)){
			        uni.showToast({ title: '请输入正确的手机号', icon: "none" });
			        return false;
			    }
			    if(!this.verCode) {
			        uni.showToast({title: '验证码不能为空',icon:"none"});
			        return ;
			    }
			    uni.showLoading()
			    this.$api.sendRequest({
			        url: '/loginByCode',
			        data: {
			            telephone:this.phone,
			            code:this.verCode
			        },
			        success: res => {
			            uni.hideLoading()
			            if(res.code && res.code==200){
			               this.login(res.data)
			               uni.switchTab({
			                   url:'/pages/index/index'
			               })
			            }else{
			                uni.showToast({
			                    icon:'none',
			                    title:res.message
			                })
			            }
			        }
			    });
			},
			// 获取注册验证码
			handleCode () {
			    if(this.getCodeisWaiting){
			        uni.showToast({title: '验证码不能重复发送',icon:"none"});
			        return;
			    }
			    let phones=/^1(3|4|5|6|7|8|9)\d{9}$/;
			    if(!phones.test(this.phone)){
			        uni.showToast({ title: '请输入正确的手机号', icon: "none" });
			        return false;
			    }
			    this.getCodeisWaiting = true;
			    uni.showLoading()
			    setTimeout(()=>{
			    	this.setTimer();
			    },1000)
			    
			},
			setTimer(){
				let holdTime = 60;
			    uni.hideLoading()
				this.Timer = setInterval(()=>{
					if(holdTime<=0){
						this.acquire = "验证码"
						clearInterval(this.Timer);
						return ;
					}
			        if(holdTime==55){
			            this.$api.sendRequest({
							method:'GET',
			                url: '/getLoginCode',
			                data: {telephone:this.phone},
			                success: res => {
			                    if(res.code && res.code==200){
			                       uni.showToast({title: '验证码已发送',icon:"none"});
			                    }else{
			                        uni.showModal({
			                        	showCancel:false,
			                            content:res.message
			                        })
			                        this.acquire = "验证码"
			                        this.getCodeisWaiting = false;
			                        clearInterval(this.Timer);
			                    }
			                },
							fail:res => {
								this.acquire = "验证码"
								this.getCodeisWaiting = false;
								clearInterval(this.Timer);
							}
			            });
			        }
					this.acquire = holdTime+'(s)'
					holdTime--;
					// this.time = holdTime
				},1000)
			},
        }
    }
</script>

<style lang="scss" scoped>
	.container {
		padding-top: 204upx;
	}
   .logo {
	   width: 176upx;
	   height: 176upx;
	   margin: 0 auto 105upx;
	   image {
		   width: 100%;
		   height: 100%;
	   }
   }
   .input {
	    position: relative;
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 555upx;
		box-sizing: border-box;
		padding: 0 15upx 14upx;
		margin: 40upx auto;
		border-bottom: 2upx solid #DDDDDD;
		.img {
			display: block;
			width: 29upx;
			height: 46upx;
		}
		.uniInput {
			width: calc(100% - 60upx);
			font-size: 30upx;
			color: #333;
		}
		.vscode {
			position: absolute;
			right: 0;
			top: 0;
			width: 169upx;
			height: 45upx;
			line-height: 45upx;
			text-align: center;
			font-size: 22upx;
			font-weight: 400;
			color: #FFFFFF;
			background: #EB0000;
			border-radius: 10upx;
		}
   }
   .r_l {
	   width: 555upx;
	   display: flex;
	   justify-content: space-between;
	   margin: 36upx auto;
	   text {
		   font-size: 29upx;
		   font-weight: 400;
		   color: #151515;
	   }
   }
   .save {
		width: 555upx;
		height: 90upx;
		line-height: 90upx;
		text-align: center;
		margin:100upx auto 0;
		font-size: 38upx;
		font-weight: 400;
		color: #FFFFFF;
		background: #EB0000;
		border-radius: 10upx;
   }
</style>

