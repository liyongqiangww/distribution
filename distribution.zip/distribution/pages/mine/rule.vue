<template>
    <view>
        <view class="article">
            <view class="content" >{{content}}</view>
        </view>
    </view>
</template>

<script>
	import {
	    mapState,
	    mapMutations
	} from 'vuex'
    export default {
        data () {
            return {
                detail:{},
                content:''
            }
        },
		computed:{
		    ...mapState(['hasLogin','userInfo'])
		},
        onLoad(option) {
           this.getDetail (option.type)  
        },
        methods: {
            getDetail (type) {
                let that = this
                uni.showLoading()
                that.$api.sendRequest({
                	method:'GET',
                    url: '/management/getByType',
                    data: {
                		type:type
                	},
                    success: res => {
                		uni.hideLoading()
                		this.content = res.data.descr
                    }
                });
            }
        }
    }
</script>

<style lang="scss">
    .article {
        width: 100%;
        box-sizing: border-box;
        padding: 0 32upx;
        border-top: 2upx solid #F2F4FA;
        .content {
            width: 100%;
            line-height: 50upx;
            margin-top: 30upx;
            font-size: 30upx;
        }
    }
</style>
