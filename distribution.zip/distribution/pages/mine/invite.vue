<template>
	<view class="container">
		<canvas canvas-id="myCanvas" style="position: absolute;top:0;left:0;z-index: -333;width: 375px;height: 677px;background-color: #fff;"/>
		<image class="bg" src="/static/images/mine/invite.png"></image>
		<view class="qcode">
			<view class="img">
				<image src="/static/images/qr.png" mode=""></image>
			</view>
			<view class="title">
				<view class="txt">
					专属邀请码：<text>{{invitecode}}</text>
				</view>
				<image class="pm" src="/static/images/pm.png" mode=""></image>
			</view>
		</view>
		<image :src="img" @longpress="save" mode="" style="position: absolute;top:0;left:0;z-index: 10;opacity: 0;width: 100%;height: 677px;background-color: #999999;"></image>
	</view>
</template>

<script>
	export default {
		data () {
			return {
				img:'',
				invitecode:''
			}
		},
		onReady() {
		  this.getCanvasImg()  
		},
		onLoad(option) {
			this.invitecode = option.inviteCode
		},
		methods: {
			save () {
				let that = this
				uni.canvasToTempFilePath({
				    x: 0,
				    y: 0,
				    width: 375,
				    height: 677,
				    destWidth: 750,
				    destHeight: 1354,
				    fileType:'jpg',
				    quality:1,
				    canvasId: 'myCanvas',
				    success: function (res) {
						that.img = res.tempFilePath
				    },
				    fail: function (res) {
				        console.log(res)
				    }
				})
			},
			getCanvasImg () {
			    let that = this
				const ctx = uni.createCanvasContext('myCanvas')
				ctx.setFillStyle('white')
				ctx.fillRect(10, 10, 375, 677)
				ctx.stroke()
				ctx.drawImage('/static/images/mine/invite.png' || '', 0, 0, 375, 677)
				ctx.drawImage('/static/images/xx.png' || '', 49, 480, 280, 100)
				ctx.drawImage('/static/images/qr.png' || '', 58, 486, 85, 85)
				ctx.setFontSize(16)
				ctx.fillText('专属邀请码：'+that.invitecode, 155, 520)
				ctx.draw()
			},
			drawTextOn(mainCtx,t,x,y,w){
			
			    var chr = t.split("");
			    var temp = "        ";              
			    var row = [];
			    mainCtx.setTextAlign('left')
			    mainCtx.textBaseline = "middle";
			    for(var a = 0; a < chr.length; a++){
			        if( mainCtx.measureText(temp).width < w ){
			            ;
			        }
			        else{
			            row.push(temp);
			            temp = "";
			        }
			        temp += chr[a];
			    }
			
			    row.push(temp);
			
			    for(var b = 0; b < row.length; b++){
			        mainCtx.fillText(row[b],x,y+(b+1)*20);
			    }
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		position: relative;
		width: 100%;
		height: 100vh;
		overflow: hidden;
	}
	.bg {
		display: block;
		width: 100%;
		height: 100vh;
	}
	.qcode {
		position: absolute;
		left: 0;
		right: 0;
		bottom: 135upx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 625upx;
		height: 195upx;
		box-sizing: border-box;
		padding:0 15upx;
		margin: auto;
		border-radius: 10upx;
		background: #1227CD;
		.img {
			width: 169upx;
			height: 169upx;
			image {
				display: block;
				width: 100%;
				height: 100%;
				border-radius: 10upx;
			}
		}
		.title {
			width: calc(100% - 186upx);
			.txt {
				font-size: 29upx;
				font-weight: 300;
				color: #FFFFFF;
				text {
					font-size: 40upx;
					font-weight: bold;
				}
			}
			.pm {
				display: block;
				width: 100%;
				height: 80upx;
				border-radius: 5upx;
				margin-top: 10upx;
			}
		}
	}
</style>
