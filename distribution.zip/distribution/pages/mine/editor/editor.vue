<template>
	<view>
        <view class="bloom">
            <image src="/static/images/bg.png"></image>
        </view>
        <!-- 中心列表 -->
        <view class="list-content">
        	<view class="list">
        		<view class="li " @tap="goJump('/pages/mine/editor/nickname')">
        			<view class="left">
        			    <text class="text">昵称</text>
        			</view>
        			<view class="right">
                        <text class="text">{{userInfo.nickname || '昵称'}}</text>
        			    <image class="to" src="/static/images/more.png"></image>
        			</view>
        		</view>
                <view class="li " @tap="goJump('/pages/mine/editor/head')">
                	<view class="left">
                	    <text class="text">头像</text>
                	</view>
                	<view class="right">
                        <image class="touxiang" :src="userInfo.avaurl ? userInfo.avaurl : '/static/images/avator.png'"></image>
                	    <image class="to" src="/static/images/more.png"></image>
                	</view>
                </view>
                <!-- <view class="li ">
                	<view class="left">
                	    <text class="text">密码设置</text>
                	</view>
                	<view class="right">
                	    <image class="to" src="/static/images/more.png"></image>
                	</view>
                </view> -->
                <view class="li " @tap="goJump('/pages/mine/editor/phone')">
                	<view class="left">
                	    <text class="text">手机号修改</text>
                	</view>
                	<view class="right">
                	    <image class="to" src="/static/images/more.png"></image>
                	</view>
                </view>
                <view class="li " @tap="toLogOut">
                	<view class="left">
                	    <text class="text">退出账户</text>
                	</view>
                	<view class="right">
                	    <image class="to" src="/static/images/more.png"></image>
                	</view>
                </view>
        	</view>
        </view>    
	</view>
</template>

<script>
    import {
        mapState,mapMutations
    } from 'vuex'
	export default {
		data() {
			return {
               isShow:false 
			}
		},
        computed: mapState(['hasLogin', 'userInfo']),
		onLoad() {
		},
		methods: {
            ...mapMutations(['logout']),
            goJump(url) {
                uni.navigateTo({
                    url:url
                })
            },
            toLogOut () {
                let that = this
                uni.showModal({
                    title: '提示',
                    content: '确认要退出当前登录？',
                    success: function (res) {
                        if (res.confirm) {
                            that.logout()
                        } else if (res.cancel) {
                            console.log('用户点击取消');
                        }
                    }
                });
            }
		}
	}
</script>

<style lang="scss">
    .list{
    	width:100%;
        border-top: 2upx solid #EDEFF5;
    	.li{
            display:flex;
            justify-content: space-between;
            align-items:center;
    		width:100%;
    		box-sizing: border-box;
    		padding:32upx;
            background-color: #fff;
    		border-bottom:1px solid #EEEEEE;
    		.left{
                .text {
                    font-size: 30upx;
                    color:#333333;
                }
    		}
            .right {
                .to {
                    width: 14upx;
                    height: 25upx;
                    margin-left: 15upx;
                    vertical-align: middle;
                }
                .touxiang {
                    width: 54upx;
                    height: 54upx;
                    border-radius: 50%;
                    vertical-align: middle;
                }
                .text {
                    font-size: 30upx;
                    color: #999999;
                    vertical-align: middle;
                }
            }
    	}
    } 
</style>
