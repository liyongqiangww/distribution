<template>
    <view>
        <view class="bloom">
            <image src="/static/images/bg.png"></image>
        </view>
        <view class="form">
            <view class="form-item">
                <view class="title">
                    昵称
                </view>
                <view class="input">
                    <input type="text" v-model="nickname" placeholder="请输入昵称" placeholder-style="color:#999;font-size:30upx"/>
                </view>
            </view>
        </view>
        <view class="btn" @tap="submit">
            保存
        </view>
    </view>
</template>

<script>
    import {
        mapState,
        mapMutations
    } from 'vuex'
    export default {
        data () {
            return {
                nickname:''
            }
        },
        computed:mapState(['hasLogin', 'userInfo']),
        methods:{
            ...mapMutations(['login']),
            submit (){
                if(!this.nickname) {
                    uni.showToast({
                        icon:'none',
                        title:'请输入您的昵称'
                    })
                    return ;    
                }
                this.$api.sendRequest({
                	url: '/api/mine/user_upsz',
                	data: {
                        uid:this.userInfo.id,
                        nickname:this.nickname,
                        phone:'',
                        avaurl:''
                	},
                	success: res => {
                		if(res.code && res.code == 200){
                            this.userInfo.nickname = res.result.nickname
                            this.login(this.userInfo)
                            uni.redirectTo({
                		       url:'/pages/mine/editor/editor'
                		    })
                		}
                	}
                });
            }
        }
    }
</script>

<style lang="scss" scoped>
    .form {
        width: 100%;
        box-sizing: border-box;
        padding: 0 32upx;
        border-top: 2upx solid #EDEFF5;
        .form-item {
            width: 100%;
            margin-top: 30upx;
            .title {
                font-weight: bold;
                font-size: 30upx;
                color: #333;
            }
            .input {
                width: 100%;
                box-sizing: border-box;
                padding: 30upx;
                margin-top: 18upx;
                border-radius: 6upx;
                background-color: #FAF9F7;
                input {
                    width: 100%;
                    font-size: 28upx;
                    color: #666;
                }
            }
        }
    }
    .btn {
        width: 687upx;
        height: 80upx;
        line-height: 80upx;
        text-align: center;
        margin: 100upx auto 50upx;
        color: #fff;
        font-size: 32upx;
        background: linear-gradient(-90deg, #5E3ECF, #9B67FB);
        box-shadow: 0px 0px 20upx 0px rgba(155, 103, 251, 0.79);
        border-radius: 40upx;
    }
</style>
