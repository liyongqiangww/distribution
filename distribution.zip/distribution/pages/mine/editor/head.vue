<template>
	<view>
        <view class="bloom">
            <image src="/static/images/bg.png"></image>
        </view>
        <view class="shop">
            <view class="touxiang" @tap="upload">
                <image :src="img"></image>
            </view>
            <image-cropper :src="tempFilePath" @confirm="confirm" @cancel="cancel"></image-cropper>
        </view>
        <view class="btn" @tap="save">
            保存
        </view>
	</view>
</template>

<script>
    import ImageCropper from "@/components/invinbg-image-cropper/invinbg-image-cropper.vue";
    import { pathToBase64, base64ToPath } from '@/js_sdk/index.js';
    import {
        mapState,
        mapMutations
    } from 'vuex'
	export default {
		data() {
			return {
                img:'/static/images/avator.png',
                tempFilePath: '',
                cropFilePath: '',
			}
		},
        computed: mapState(['hasLogin', 'userInfo']),
        components: {ImageCropper},
		onLoad() {
            
		},
		methods: {
            ...mapMutations(['login']),
            save () {
                if(!this.cropFilePath){
                	uni.showToast({title:'请选择图片',icon:'none'});
                	return ;
                }
                uni.showLoading({title: '加载中'});
                this.$api.sendRequest({
                	url: '/api/mine/user_upsz',
                	data: {
                        uid:this.userInfo.id,
                        nickname:'',
                        phone:'',
                        avaurl:this.img
                	},
                	success: res => {
                        uni.hideLoading();
                		if(res.code && res.code == 200){
                            this.userInfo.avaurl = res.result.avaurl
                            this.login(this.userInfo)
                            uni.redirectTo({
                		       url:'/pages/mine/editor/editor'
                		    })
                		}
                	}
                });
                
            },
            upload() {
                uni.chooseImage({
                    count: 1, //默认9
                    sizeType: ['compressed'], //可以指定是原图还是压缩图，默认二者都有
                    success: (res) => {
                        this.tempFilePath = res.tempFilePaths.shift()
                    }
                });
            },
            confirm(e) {
                let that = this
                this.tempFilePath = ''
                uni.showLoading({title: '上传中'});
                pathToBase64(e.detail.tempFilePath)
                .then(base64 => {
                    uni.hideLoading();
                    this.$api.sendRequest({
                    	url: '/api/mine/upload',
                    	data: {
                            img:base64
                    	},
                    	success: res => {
                    		if(res.code && res.code == 200){
                                that.img = res.result
                                that.cropFilePath = res.result
                    		}
                    	}
                    });
                })
            },
            cancel() {
                console.log('canceled')
            }
    
		}
	}
</script>

<style lang="scss">
    .shop {
        width: 300upx;
        height: 300upx;
        margin:200upx auto 0;
        .touxiang {
            width: 100%;
            height: 100%;
            image {
                width: 100%;
                height: 100%;
            }
        }
    }
    .btn {
        width: 687upx;
        height: 80upx;
        line-height: 80upx;
        text-align: center;
        margin: 100upx auto 50upx;
        color: #fff;
        font-size: 32upx;
        background: linear-gradient(-90deg, #5E3ECF, #9B67FB);
        box-shadow: 0px 0px 20upx 0px rgba(155, 103, 251, 0.79);
        border-radius: 40upx;
    }
</style>
