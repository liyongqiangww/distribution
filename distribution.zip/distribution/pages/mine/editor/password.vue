<template>
    <view class="container">
		<!-- <view class="input">
			<image class="img" src="/static/images/pass.png"></image>
			<input class="uniInput" placeholder="请输入原密码" placeholder-style="fotn-size:30upx;color: #939393;"/>
		</view> -->
		<view class="input">
			<image class="img" src="/static/images/pass.png"></image>
			<input class="uniInput" v-model="pass" placeholder="请输入新密码" placeholder-style="font-size:30upx;color: #939393;"/>
		</view>
		<view class="input">
			<image class="img" src="/static/images/pass.png"></image>
			<input class="uniInput" v-model="rePass" placeholder="请再次输入新密码" placeholder-style="font-size:30upx;color: #939393;"/>
		</view>
		<view class="input">
			<image class="img" src="/static/images/mine/phone.png"></image>
			<input class="uniInput" v-model="phone" placeholder="请输入手机号" placeholder-style="font-size:30upx;color: #939393;"/>
		</view>
		<view class="input">
			<image class="img" src="/static/images/code.png"></image>
			<input class="uniInput" v-model="code" maxlength="10" placeholder="请输入验证码" placeholder-style="font-size:30upx;color: #939393;"/>
			<view class="vscode" @tap="handleCode">
				{{acquire}}
			</view>
		</view>
		
		<view class="save btn" @tap="save">
			确认修改
		</view>
    </view>
</template>
<script>
    import {
        mapState,
        mapMutations
    } from 'vuex'
	import aesEncrypt from '@/common/aesEncrypt.js'
    export default {
        data() {
            return {
				getCodeisWaiting:false,
				acquire:'验证码',//获取验证码
                pass:'',
				rePass:'',
				phone:'',
				code:'',
            };
        },
		computed:{
		    ...mapState(['hasLogin','userInfo'])
		},
        onLoad() {
			
        },
        methods: {
            ...mapMutations(['login']),
            toJump (url) {
				uni.navigateTo({
					url:url
				})
			},
			save () {
				let that = this;
				let phones=/^1(3|4|5|6|7|8|9)\d{9}$/;
				if(!this.pass){
					uni.showToast({ title: '请输入密码', icon: "none" });
					return false;
				}
				if(this.pass!=this.rePass){
					uni.showToast({ title: '两次密码不一致', icon: "none" });
					return false;
				}
				if(!phones.test(this.phone)){
				    uni.showToast({ title: '请输入正确的手机号', icon: "none" });
				    return false;
				}
				if(!this.code){
				    uni.showToast({ title: '请输入验证码', icon: "none" });
				    return false;
				}
				uni.showLoading()
				that.$api.sendRequest({
				    url: '/forgetPassWord',
					header:{
						'Content-Type':'application/json',
						'Authentication':that.userInfo.token
					},
				    data: {
						code:that.code,
						password:aesEncrypt.encrypt(that.rePass),
						telephone:that.phone
					},
				    success: res => {
				        uni.hideLoading()
						if(res.code && res.code==200){
							uni.switchTab({
								url:'/pages/mine/index'
							})
						}else{
							uni.showModal({
								showCancel:false,
							    content:res.message
							})
							that.acquire = "验证码"
							that.getCodeisWaiting = false;
							clearInterval(that.Timer);
						}
				    }
				});
			},
			// 获取注册验证码
			handleCode () {
			    if(this.getCodeisWaiting){
			        uni.showToast({title: '验证码不能重复发送',icon:"none"});
			        return;
			    }
			    let phones=/^1(3|4|5|6|7|8|9)\d{9}$/;
			    if(!phones.test(this.phone)){
			        uni.showToast({ title: '请输入正确的手机号', icon: "none" });
			        return false;
			    }
			    this.getCodeisWaiting = true;
			    uni.showLoading()
			    setTimeout(()=>{
			    	this.setTimer();
			    },1000)
			    
			},
			setTimer(){
				let holdTime = 60;
			    uni.hideLoading()
				this.Timer = setInterval(()=>{
					if(holdTime<=0){
						this.acquire = "验证码"
						clearInterval(this.Timer);
						return ;
					}
			        if(holdTime==55){
			            this.$api.sendRequest({
							method:'GET',
			                url: '/getRegiterCode',
			                data: {telephone:this.phone},
			                success: res => {
			                    if(res.code && res.code==200){
			                       uni.showToast({title: '验证码已发送',icon:"none"});
			                    }else{
			                        uni.showModal({
			                        	showCancel:false,
			                            content:res.message
			                        })
			                        this.acquire = "验证码"
			                        this.getCodeisWaiting = false;
			                        clearInterval(this.Timer);
			                    }
			                },
							fail:res => {
								this.acquire = "验证码"
								this.getCodeisWaiting = false;
								clearInterval(this.Timer);
							}
			            });
			        }
					this.acquire = holdTime+'(s)'
					holdTime--;
					// this.time = holdTime
				},1000)
			},
        }
    }
</script>

<style lang="scss" scoped>
	.container {
		padding-top: 30upx;
	}
   .input {
	    position: relative;
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 555upx;
		box-sizing: border-box;
		padding: 0 15upx 14upx;
		margin: 40upx auto;
		border-bottom: 2upx solid #DDDDDD;
		.img {
			display: block;
			width: 29upx;
			height: 46upx;
		}
		.xmg {
			display: block;
			width: 47upx;
			height: 43upx;
		}
		.uniInput {
			width: calc(100% - 60upx);
			font-size: 30upx;
			color: #333;
		}
		.vscode {
			position: absolute;
			right: 0;
			top: 0;
			width: 169upx;
			height: 45upx;
			line-height: 45upx;
			text-align: center;
			font-size: 22upx;
			font-weight: 400;
			color: #FFFFFF;
			background: #EB0000;
			border-radius: 10upx;
		}
   }
   .r_l {
	   width: 555upx;
	   display: flex;
	   justify-content: space-between;
	   margin: 25upx auto;
	   text {
		   font-size: 29upx;
		   font-weight: 400;
		   color: #151515;
	   }
   }
   .save {
		width: 555upx;
		height: 90upx;
		line-height: 90upx;
		text-align: center;
		margin:60upx auto 0;
		font-size: 38upx;
		font-weight: 400;
		color: #FFFFFF;
		background: #EB0000;
		border-radius: 10upx;
   }
   .secrity {
	   width: 555upx;
	   margin: 30upx auto;
	   font-size: 22upx;
	   font-weight: 400;
	   color: #939393;
	   .txt {
		   color: #EB0000;
	   }
   }
</style>

