<template>
    <view class="container">
        <view class="logo">
        	<image src="/static/images/logo.png"></image>
        </view>
		<view class="input">
			<image class="img" src="/static/images/mine/phone.png"></image>
			<input class="uniInput" v-model="account" placeholder="请输入手机号" placeholder-style="font-size:30upx;color: #939393;"/>
		</view>
		<view class="input">
			<image class="img" src="/static/images/code.png"></image>
			<input class="uniInput" password="true" v-model="password" placeholder="请输入密码" placeholder-style="font-size:30upx;color: #939393;"/>
		</view>
		<view class="save btn" @tap="AccountLogin">
			登录
		</view>
		<view class="r_l">
			<text @tap="toJump('register')">注册</text>
			<text @tap="toJump('login')">验证码登录</text>
		</view>
    </view>
</template>
<script>
	import aesEncrypt from '@/common/aesEncrypt.js'
    import {
        mapMutations
    } from 'vuex';
    export default {
        data() {
            return {
                account:'',
                password:'',
            };
        },
        onLoad() {
			uni.clearStorage()
        },
        methods: {
            ...mapMutations(['login']),
            toJump (url) {
				uni.navigateTo({
					url:url
				})
			},
			AccountLogin (){
			    if(!this.account){
			        uni.showToast({ title: '请输入账号', icon: "none" });
			        return false; 
			    }
			    if(!this.password){
			        uni.showToast({ title: '请输入密码', icon: "none" });
			        return false; 
			    }
			    uni.showLoading()
			    this.$api.sendRequest({
			        url: '/login',
			        data: {
			            telephone:this.account,
			            password:aesEncrypt.encrypt(this.password)
			        },
			        success: res => {
			            uni.hideLoading()
			            if(res.code && res.code==200){
			               this.login(res.data)
			               uni.switchTab({
			                   url:'/pages/index/index'
			               })
			            }else{
			                uni.showToast({
			                    icon:'none',
			                    title:res.message
			                })
			            }
			        }
			    });
			    
			}
        }
    }
</script>

<style lang="scss" scoped>
	.container {
		padding-top: 204upx;
	}
   .logo {
	   width: 176upx;
	   height: 176upx;
	   margin: 0 auto 105upx;
	   image {
		   width: 100%;
		   height: 100%;
	   }
   }
   .input {
	    position: relative;
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 555upx;
		box-sizing: border-box;
		padding: 0 15upx 14upx;
		margin: 40upx auto;
		border-bottom: 2upx solid #DDDDDD;
		.img {
			display: block;
			width: 29upx;
			height: 46upx;
		}
		.uniInput {
			width: calc(100% - 60upx);
			font-size: 30upx;
			color: #333;
		}
		.vscode {
			position: absolute;
			right: 0;
			top: 0;
			width: 169upx;
			height: 45upx;
			line-height: 45upx;
			text-align: center;
			font-size: 22upx;
			font-weight: 400;
			color: #FFFFFF;
			background: #EB0000;
			border-radius: 10upx;
		}
   }
   .r_l {
	   width: 555upx;
	   display: flex;
	   justify-content: space-between;
	   margin: 36upx auto;
	   text {
		   font-size: 29upx;
		   font-weight: 400;
		   color: #151515;
	   }
   }
   .save {
		width: 555upx;
		height: 90upx;
		line-height: 90upx;
		text-align: center;
		margin:100upx auto 0;
		font-size: 38upx;
		font-weight: 400;
		color: #FFFFFF;
		background: #EB0000;
		border-radius: 10upx;
   }
</style>

