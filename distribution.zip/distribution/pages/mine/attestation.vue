<template>
	<view>
		<view class="pic">
			<view class="item" @tap="uploadPic(1)">
				<image :src="img1?$imgUrl + '/' + img1:'/static/images/mine/zm.png'" mode=""></image>
				<text>身份证正面</text>
			</view>
			<view class="item" @tap="uploadPic(2)">
				<image :src="img2?$imgUrl + '/' + img2 : '/static/images/mine/fm.png'" mode=""></image>
				<text>身份证反面</text>
			</view>	
		</view>
		<view class="wrap">
			<view class="input">
				<text class="txt">真实姓名</text>
				<input class="uniInput" v-model="name" placeholder="请输入真实姓名" placeholder-style="fotn-size:30upx;color: #939393;"/>
			</view>
			<view class="input">
				<text class="txt">身份证号</text>
				<input class="uniInput" v-model="card" placeholder="请输入身份证号" placeholder-style="fotn-size:30upx;color: #939393;"/>
			</view>
			<view class="input">
				<text class="txt">手机号</text>
				<input class="uniInput" v-model="phone" placeholder="请输入手机号" placeholder-style="fotn-size:30upx;color: #939393;"/>
			</view>
			<view class="input">
				<text class="txt">验证码</text>
				<input class="uniInput" v-model="code" maxlength="10" placeholder="请输入验证码" placeholder-style="fotn-size:30upx;color: #939393;"/>
				<view class="vscode" @tap="handleCode">
					{{acquire}}
				</view>
			</view>
			<view class="save btn" @tap="save">
				实名认证
			</view>
		</view>
	</view>
</template>

<script>
	import {
	    mapState,
	    mapMutations
	} from 'vuex'
	export default {
		data () {
			return {
				img1:'',
				img2:'',
				name:'',
				card:'',
				phone:'',
				getCodeisWaiting:false,
				acquire:'验证码',//获取验证码
				code:''
			}
		},
		computed:{
		    ...mapState(['hasLogin','userInfo'])
		},
		methods:{
			save () {
				let that = this;
				let phones=/^1(3|4|5|6|7|8|9)\d{9}$/,identy=/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
				if(!this.img1){
					uni.showToast({
						icon:'none',
						title:'请上传身份证正面'
					})
					return ;
				}
				if(!this.img2){
					uni.showToast({
						icon:'none',
						title:'请上传身份证反面'
					})
					return ;
				}
				if(!this.name){
					uni.showToast({
						icon:'none',
						title:'请上输入真实姓名'
					})
					return ;
				}
				if(!(identy.test(this.card))){
				    uni.showToast({ title: '请输入正确的身份证号', icon: "none" });
				    return false; 
				} 
				if(!phones.test(this.phone)){
				    uni.showToast({ title: '请输入正确的手机号', icon: "none" });
				    return false;
				}
				if(!this.code){
				    uni.showToast({ title: '请输入验证码', icon: "none" });
				    return false;
				}
				uni.showLoading()
				that.$api.sendRequest({
					url: '/user-authentication/insert',
					header: {
						'Content-Type': 'application/json',
						'Authentication': that.userInfo.token
					},
					data: {
					    "telephone":that.phone,
					    "userName":that.name,
					    "userIdentityCard":that.card,
					    "userIdentityCardImgFront":that.img1,
					    "userIdentityCardImgVerso":that.img2,
					    "code":that.code
					},
					success: res => {
						uni.hideLoading()
						if (res.code && res.code == 200) {
							uni.switchTab({
								url:'/pages/mine/index'
							})
						} else {
							uni.showModal({
								showCancel:false,
							    content:res.message
							})
							that.acquire = "验证码"
							that.getCodeisWaiting = false;
							clearInterval(that.Timer);
							return
						}
				
				
					}
				});
			},
			uploadPic (type) {
				let that = this
				uni.chooseImage({
					count: 1, //默认9
					sizeType: ['compressed'], //可以指定是原图还是压缩图，默认二者都有
					success: (res) => {
						uni.showLoading()
						uni.uploadFile({
							url: that.$fileUrl + '/upload/identityCard',
							filePath: res.tempFilePaths.shift(),
							fileType: 'image',
							name: "file",
							success: resc => {
								uni.hideLoading()
								// 修改头像掉接口
								if(type==1) {
									that.img1 = JSON.parse(resc.data).data
								}else{
									that.img2 = JSON.parse(resc.data).data
								}
							}
						});
					}
				});	
			},
			// 获取注册验证码
			handleCode () {
			    if(this.getCodeisWaiting){
			        uni.showToast({title: '验证码不能重复发送',icon:"none"});
			        return;
			    }
			    let phones=/^1(3|4|5|6|7|8|9)\d{9}$/;
			    if(!phones.test(this.phone)){
			        uni.showToast({ title: '请输入正确的手机号', icon: "none" });
			        return false;
			    }
			    this.getCodeisWaiting = true;
			    uni.showLoading()
			    setTimeout(()=>{
			    	this.setTimer();
			    },1000)
			    
			},
			setTimer(){
				let holdTime = 60;
			    uni.hideLoading()
				this.Timer = setInterval(()=>{
					if(holdTime<=0){
						this.acquire = "验证码"
						clearInterval(this.Timer);
						return ;
					}
			        if(holdTime==55){
			            this.$api.sendRequest({
							method:'GET',
			                url: '/user-authentication/getCode',
			                header: {
			                	'Authentication': this.userInfo.token
			                },
							data: {telephone:this.phone},
			                success: res => {
			                    if(res.code && res.code==200){
			                       uni.showToast({title: '验证码已发送',icon:"none"});
			                    }else{
			                        uni.showModal({
			                        	showCancel:false,
			                            content:res.message
			                        })
			                        this.acquire = "验证码"
			                        this.getCodeisWaiting = false;
			                        clearInterval(this.Timer);
			                    }
			                },
							fail:res => {
								this.acquire = "验证码"
								this.getCodeisWaiting = false;
								clearInterval(this.Timer);
							}
			            });
			        }
					this.acquire = holdTime+'(s)'
					holdTime--;
					// this.time = holdTime
				},1000)
			},
		}
	}
</script>

<style lang="scss" scoped>
	.pic {
		display: flex;
		justify-content: space-between;
		width: 100%;
		box-sizing: border-box;
		padding: 50upx 35upx;
		.item {
			width: 315upx;
			height: 210upx;
			text-align: center;
			image {
				display: block;
				width: 100%;
				height: 100%;
				margin-bottom: 10upx;
			}
			text {
				font-size: 26upx;
				font-weight: 400;
				color: #999999;
			}
		}
	}
	.wrap {
		width: 100%;
		box-sizing: border-box;
		padding: 40upx 21upx;
	}
	.input {
		position: relative;
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 100%;
		box-sizing: border-box;
		padding: 0 15upx 14upx;
		margin: 40upx auto;
		border-bottom: 2upx solid #DDDDDD;
		.txt {
			font-size: 26upx;
			font-weight: 400;
			color: #151515;
		}
		.uniInput {
			width: calc(100% - 140upx);
			font-size: 30upx;
			color: #333;
		}
		.vscode {
			position: absolute;
			right: 0;
			top: 0;
			width: 169upx;
			height: 45upx;
			line-height: 45upx;
			text-align: center;
			font-size: 22upx;
			font-weight: 400;
			color: #FFFFFF;
			background: #EB0000;
			border-radius: 10upx;
		}
	}
	.save {
		width: 555upx;
		height: 90upx;
		line-height: 90upx;
		text-align: center;
		margin:100upx auto 0;
		font-size: 38upx;
		font-weight: 400;
		color: #FFFFFF;
		background: #EB0000;
		border-radius: 10upx;
	}
</style>
