<template>
    <view>
		<view class="cater">
			<view class="txt" :class="index == cIndex ? 'on':''" v-for="(item,index) in cater" :key="index" @tap="selectOn(index)">{{item}}</view>
		</view>
        <view class="article">
            <view class="content" >{{content}}</view>
        </view>
    </view>
</template>

<script>
	import {
	    mapState,
	    mapMutations
	} from 'vuex'
    export default {
        data () {
            return {
				cIndex:0,
				// type取值 profile 公司简介 policy 隐私政策 agreement 服务协议
				type:['profile','agreement','policy'],
				cater:['公司简介','服务协议','隐私政策'],
                content:''
            }
        },
		computed:{
		    ...mapState(['hasLogin','userInfo'])
		},
        onLoad() {
           this.getDetail ()  
        },
        methods: {
			selectOn (index) {
				this.cIndex = index
				this.getDetail () 
			},
            getDetail () {
				let that = this
				uni.showLoading()
				that.$api.sendRequest({
					method:'GET',
				    url: '/management/getByType',
					header:{
						// 'Content-Type':'application/json',
						'Authentication':that.userInfo.token
					},
				    data: {
						type:this.type[this.cIndex]
					},
				    success: res => {
						uni.hideLoading()
						this.content = res.data.descr
				    	if(res.code && res.code == 200){
				    	   // var richtext =  res.result.content;
				    	   // const regex = new RegExp('<img', 'gi');
				    	   // // 判断是否头图片
				    	   // if(richtext.indexOf('img') != -1){
				    	   //     richtext= richtext.replace(regex, `<img style="width: 100%;border-radius:5px"`);
				    	   // }
				    	   // this.content = richtext;
				    	}
				    }
				});
            }
        }
    }
</script>

<style lang="scss" scoped>
	.cater {
		display: flex;
		justify-content: space-between;
		width: 100%;
		box-sizing: border-box;
		padding:82upx 80upx 0;
		border-bottom: 2upx solid #DDDDDD;
		.txt {
			padding-bottom: 14upx;
			font-size: 38upx;
			font-weight: 400;
			color: #151515;
		}
		.on {
			color: #EB0000;
			border-bottom: 4upx solid #EB0000;
		}
	}
    .article {
        width: 100%;
        box-sizing: border-box;
        padding: 0 32upx;
		margin-top: 30upx;
        .content {
            width: 100%;
            line-height: 50upx;
            margin-top: 30upx;
            font-size: 30upx;
        }
    }
</style>
