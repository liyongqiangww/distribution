<template>
	<view>
		<view class="textarea">
			<textarea v-model="textarea" placeholder="请描述您想反馈的问题" placeholder-style="color:#939393;font-size:30upx"/>
		</view>
		<view class="upload" @tap="uploadPic">
			<image class="img" src="/static/images/mine/upload.png"></image>
		</view>
		<view class="imgs">
			<view class="img-item" v-for="(item,index) in imgs" :key="index" @tap="preview_imgs(imgs,index)">
				<image class="close" src="/static/images/mine/close.png"></image>
				<image class="Img" :src="item" mode="widthFix" ></image>
			</view>
		</view>
		<view class="lx">
			联系方式
		</view>
		<view class="input">
			<image class="img" src="/static/images/mine/phone.png"></image>
			<input class="uniInput" v-model="phone" placeholder="请输入您的联系电话" placeholder-style="fotn-size:30upx;color: #939393;"/>
		</view>
		<view class="save btn" @tap="save">
			提交
		</view>
	</view>
</template>

<script>
	import {
	    mapState,
	    mapMutations
	} from 'vuex'
	export default {
		data (){
			return {
				textarea:'',
				imgs:[],
				phone:''
			}
		},
		computed:{
		    ...mapState(['hasLogin','userInfo'])
		},
		onLoad() {
			
		},
		methods: {
			preview_imgs (urls,current) {
				uni.previewImage({
					urls: urls,
					loop:true,
					current:current
				});
			},
			uploadPic () {
				uni.chooseImage({
				    count: 6, //默认9
				    sizeType: ['compressed'], //可以指定是原图还是压缩图，默认二者都有
				    success: (res) => {
				        this.imgs = res.tempFilePaths
				    }
				});
			},
			save () {
				let that = this;
				let phones=/^1(3|4|5|6|7|8|9)\d{9}$/;
				if(!this.textarea) {
					uni.showToast({ title: '请输入要反馈的问题', icon: "none" });
					return ;
				}
				if(!phones.test(this.phone)){
				    uni.showToast({ title: '请输入正确的手机号', icon: "none" });
				    return false;
				}
				uni.showLoading()
				uni.uploadFile({
					url: that.$fileUrl + '/problemFeedback/insert',
					files: that.imgs,
					fileType: 'image',
					name: "files",
					header: {
						// "Content-Type": "application/x-www-form-urlencoded;application/json",
						'Authentication':that.userInfo.token
					},
					formData:{
						descr:that.textarea,
						telephone:that.phone
					},
					success(res) {
						uni.hideLoading()
						uni.switchTab({
							url:'/pages/mine/index'
						})
					}
				
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.textarea {
		width: 100%;
		box-sizing: border-box;
		padding:40upx 50upx 0;	
	    textarea {
		   width: 100%;
		   height: 150upx;
		   font-size: 28upx;
		   color: #666;
	    }
	}
	.upload {
		width: 100%;
		box-sizing: border-box;
		padding: 30upx 60upx;
		.img {
			display: block;
			width: 140upx;
			height: 140upx;
		}
	}
	.imgs {
		width: 100%;
		display: flex;
		justify-content: flex-start;
		flex-wrap: wrap;
		box-sizing: border-box;
		padding: 0upx 32upx;
		margin-top: 10upx;
		.img-item {
			position: relative;
			width: 150upx;
			height: 150upx;
			.close {
				position: absolute;
				top: 0;
				right: 0;
				width: 30upx;
				height: 30upx;
				border-radius: 50%;
				z-index: 5;
			}
			.Img {
				display: block;
				width: 100%;
				height: 100%;
				border-radius: 10upx;
			}
		}
		.img-item:nth-child(2) {
			margin: 0 10upx;
		}
		.img-item:nth-child(4) {
			margin-left:10upx;
		}
		
	}
	.lx {
		width: 100%;
		box-sizing: border-box;
		padding: 25upx 30upx;
		margin-top: 30upx;
		font-size: 42upx;
		font-weight: 400;
		color: #151515;
		background-color: #F6F6F6;
	}
	.input {
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 700upx;
		box-sizing: border-box;
		padding: 0 15upx 14upx;
		margin: 40upx auto;
		border-bottom: 2upx solid #DDDDDD;
		.img {
			display: block;
			width: 29upx;
			height: 46upx;
		}
		.uniInput {
			width: calc(100% - 60upx);
			font-size: 30upx;
			color: #333;
		}
	}
	.save {
		width: 500upx;
		height: 90upx;
		line-height: 90upx;
		text-align: center;
		margin:100upx auto 0;
		font-size: 38upx;
		font-weight: 400;
		color: #FFFFFF;
		background: #EB0000;
		border-radius: 10upx;
	}
</style>
