<template>
	<view>
		<view class="list">
			<view class="list-item" v-for="(item,index) in 3" :key="index">
				<view class="date">
					2021年11月
				</view>
				<view class="wrap">
					<view v-for="(row,index) in 5" :key="index">
						<text>11月6日18:03</text>
						<text>9974.00</text>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
</script>

<style lang="scss" scoped>
	.list {
		width: 100%;
		.list-item {
			width: 100%;
			box-sizing: border-box;
			.date {
				width: 100%;
				box-sizing: border-box;
				padding: 28upx 20upx;
				font-size: 26upx;
				font-weight: 400;
				color: #151515;
				background-color: #F6F6F6;
			}
			.wrap {
				width: 100%;
				box-sizing: border-box;
				padding: 10upx 0 30upx;
				view {
					display: flex;
					justify-content: space-between;
					box-sizing: border-box;
					padding: 27upx 20upx;
					border-bottom: 2upx solid #DDDDDD;
					text {
						font-size: 29upx;
						font-weight: bold;
						color: #151515;
					}
				}
			}
		}
	}
</style>
