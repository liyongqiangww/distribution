<template>
	<view>
		<view class="tip">
			<view class="left">
				到账银行卡
			</view>
			<view class="right">
				<view class="card">
					工商银行(***1234)
				</view>
				<view class="dec">
					2小时内到账
				</view>
			</view>
		</view>
		<view class="price">
			<view class="title">
				提现金额
			</view>
			<view class="_price">
				￥9974.00
			</view>
			<view class="dec">
				当前可提现9974.00元
			</view>
		</view>
		<view class="save btn">
			提现
		</view>
	</view>
</template>

<script>
</script>

<style lang="scss" scoped>
	.tip {
		display: flex;
		justify-content: flex-start;
		width: 100%;
		box-sizing: border-box;
		padding: 60upx;
		.left {
			width: 150upx;
			font-size: 26upx;
			font-weight: 400;
			color: #151515;
		}
		.right {
			width: calc(100% - 150upx);
			margin-left: 21upx;
			.card {
				font-size: 26upx;
				font-weight: bold;
				color: #151515;
			}
			.dec {
				margin-top: 10upx;
				font-size: 22upx;
				font-weight: 400;
				color: #939393;
			}
		}
	}
	.price {
		width: 100%;
		box-sizing: border-box;
		padding:47upx 39upx;
		border-top: 30upx solid #F6F6F6;
		.title {
			font-size: 22upx;
			font-weight: 400;
			color: #151515;
		}
		._price {
			padding: 10upx 0;
			font-size: 50upx;
			font-weight: bold;
			color: #151515;
			border-bottom: 2upx solid #DDDDDD;
		}
		.dec {
			margin-top: 13upx;
			font-size: 22upx;
			font-weight: 400;
			color: #939393;
		}
	}
	.save {
			width: 555upx;
			height: 90upx;
			line-height: 90upx;
			text-align: center;
			margin:100upx auto 0;
			font-size: 38upx;
			font-weight: 400;
			color: #FFFFFF;
			background: #EB0000;
			border-radius: 10upx;
	}
</style>
