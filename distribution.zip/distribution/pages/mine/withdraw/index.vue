<template>
	<view>
		<view class="withdraw">
			<view class="tip_title">
				添加银行卡
			</view>
			<view class="tip_dec">
				请绑定持卡人本人的银行卡
			</view>
			<view class="input">
				<text class="txt">真实姓名</text>
				<input class="uniInput" placeholder="请输入您的真实姓名" placeholder-style="fotn-size:30upx;color: #939393;"/>
			</view>
			<view class="input">
				<text class="txt">银行卡号</text>
				<input class="uniInput" placeholder="请输入银行卡号" placeholder-style="fotn-size:30upx;color: #939393;"/>
			</view>
			<view class="input">
				<text class="txt">银行</text>
				<input class="uniInput" placeholder="请输入银行名称" placeholder-style="fotn-size:30upx;color: #939393;"/>
			</view>
			<view class="input">
				<text class="txt">手机号</text>
				<input class="uniInput" placeholder="请输入银行卡预留手机号" placeholder-style="fotn-size:30upx;color: #939393;"/>
			</view>
			<view class="input">
				<text class="txt">验证码</text>
				<input class="uniInput" maxlength="10" placeholder="请输入验证码" placeholder-style="fotn-size:30upx;color: #939393;"/>
				<view class="vscode">
					获取验证码
				</view>
			</view>
			<view class="save btn" @tap="toJump">
				下一步
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data () {
			return {
				
			}
		},
		methods: {
			toJump () {
				uni.navigateTo({
					url:'price'
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.withdraw {
		width: 100%;
		box-sizing: border-box;
		padding:100upx 21upx 0;
		.tip_title,.tip_dec {
			text-align: center;
			font-weight: 400;
			color: #151515;
		}
		.tip_title {
			font-size: 34upx;
		}
		.tip_dec {
			margin-top: 10upx;
			font-size: 22upx;
		}
	}
	.input {
		position: relative;
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 100%;
		box-sizing: border-box;
		padding: 0 15upx 14upx;
		margin: 40upx auto;
		border-bottom: 2upx solid #DDDDDD;
		.txt {
			font-size: 26upx;
			font-weight: 400;
			color: #151515;
		}
		.uniInput {
			width: calc(100% - 140upx);
			font-size: 30upx;
			color: #333;
		}
		.vscode {
			position: absolute;
			right: 0;
			top: 0;
			width: 169upx;
			height: 45upx;
			line-height: 45upx;
			text-align: center;
			font-size: 22upx;
			font-weight: 400;
			color: #FFFFFF;
			background: #EB0000;
			border-radius: 10upx;
		}
   }
   .save {
   		width: 555upx;
   		height: 90upx;
   		line-height: 90upx;
   		text-align: center;
   		margin:100upx auto 0;
   		font-size: 38upx;
   		font-weight: 400;
   		color: #FFFFFF;
   		background: #EB0000;
   		border-radius: 10upx;
   }
</style>
