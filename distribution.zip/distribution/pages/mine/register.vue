<template>
    <view class="container">
        <view class="logo">
        	<image src="/static/images/logo.png"></image>
        </view>
		<view class="input">
			<image class="img" src="/static/images/invite.png"></image>
			<input class="uniInput" v-model="formData.invite" placeholder="邀请码" placeholder-style="font-size:30upx;color: #939393;"/>
		</view>
		<view class="input">
			<image class="img" src="/static/images/name.png"></image>
			<input class="uniInput" v-model="formData.name" placeholder="请输入用户名称" placeholder-style="font-size:30upx;color: #939393;"/>
		</view>
		<view class="input">
			<image class="img" src="/static/images/mine/phone.png"></image>
			<input class="uniInput" v-model="formData.phone" placeholder="请输入您的联系电话" placeholder-style="font-size:30upx;color: #939393;"/>
		</view>
		<view class="input">
			<image class="img" src="/static/images/code.png"></image>
			<input class="uniInput" v-model="formData.code" maxlength="10" placeholder="请输入验证码" placeholder-style="font-size:30upx;color: #939393;"/>
			<view class="vscode" @tap="handleCode">
				{{acquire}}
			</view>
		</view>
		<view class="input">
			<image class="img" src="/static/images/pass.png"></image>
			<input class="uniInput" password="true" v-model="formData.pass" maxlength="18" placeholder="请输入密码(6~18位)" placeholder-style="font-size:30upx;color: #939393;"/>
		</view>
		<view class="input">
			<image class="img" src="/static/images/pass.png"></image>
			<input class="uniInput" password="true" v-model="formData.rePass" placeholder="再次输入密码" placeholder-style="font-size:30upx;color: #939393;"/>
		</view>
		<view class="save btn" @tap="save">
			注册
		</view>
		<view class="r_l">
			<text @tap="toJump('login')">验证码登录</text>
			<text @tap="toJump('pass')">密码登录</text>
		</view>
		<view class="secrity" @tap="isSelect">
			<checkbox class="check" :checked="checked" color="#EB0000" style="transform:scale(0.7)" />
			勾选表示您已阅读并同意<text class="txt" @tap.stop="toJump('rule?type=agreement')">《服务协议》</text>与<text class="txt" @tap.stop="toJump('rule?type=policy')">《隐私政策》</text>
		</view>
    </view>
</template>
<script>
	// import AES from '@/common/aes.js'
	import aesEncrypt from '@/common/aesEncrypt.js'
    import {
        mapMutations
    } from 'vuex';
    export default {
        data() {
            return {
				getCodeisWaiting:false,
				acquire:'验证码',//获取验证码
                checked:false,
				formData:{
					invite:'',
					name:'',
					phone:'',
					code:'',
					pass:'',
					rePass:''
				}
            };
        },
        onLoad() {
			
        },
        methods: {
            ...mapMutations(['login']),
            toJump (url) {
				uni.navigateTo({
					url:url
				})
			},
			isSelect () {
				this.checked = !this.checked
			},
			// 获取注册验证码
			handleCode () {
			    if(this.getCodeisWaiting){
			        uni.showToast({title: '验证码不能重复发送',icon:"none"});
			        return;
			    }
			    let phones=/^1(3|4|5|6|7|8|9)\d{9}$/;
			    if(!phones.test(this.formData.phone)){
			        uni.showToast({ title: '请输入正确的手机号', icon: "none" });
			        return false;
			    }
			    this.getCodeisWaiting = true;
			    uni.showLoading()
			    setTimeout(()=>{
			    	this.setTimer();
			    },1000)
			    
			},
			setTimer(){
				let holdTime = 60;
			    uni.hideLoading()
				this.Timer = setInterval(()=>{
					if(holdTime<=0){
						this.acquire = "验证码"
						clearInterval(this.Timer);
						return ;
					}
			        if(holdTime==55){
			            this.$api.sendRequest({
							method:'GET',
			                url: '/getRegiterCode',
			                data: {telephone:this.formData.phone},
			                success: res => {
			                    if(res.code && res.code==200){
			                       uni.showToast({title: '验证码已发送',icon:"none"});
			                    }else{
			                        uni.showModal({
			                        	showCancel:false,
			                            content:res.message
			                        })
			                        this.acquire = "验证码"
			                        this.getCodeisWaiting = false;
			                        clearInterval(this.Timer);
			                    }
			                },
							fail:res => {
								this.acquire = "验证码"
								this.getCodeisWaiting = false;
								clearInterval(this.Timer);
							}
			            });
			        }
					this.acquire = holdTime+'(s)'
					holdTime--;
					// this.time = holdTime
				},1000)
			},
			save () {
				let phones=/^1(3|4|5|6|7|8|9)\d{9}$/;
				if(!this.formData.name) {
					uni.showToast({
						icon:'none',
						title:'请输入用户名称'
					})
					return ;
				}
				if(!phones.test(this.formData.phone)){
				    uni.showToast({ title: '请输入正确的手机号', icon: "none" });
				    return false;
				}
				if(!this.formData.code) {
					uni.showToast({
						icon:'none',
						title:'请输入验证码'
					})
					return ;
				}
				if(!this.formData.pass) {
					uni.showToast({
						icon:'none',
						title:'请输入密码'
					})
					return ;
				}
				if(this.formData.pass.length<6) {
					uni.showToast({
						icon:'none',
						title:'请输入6~18位数字或字母的密码'
					})
					return ;
				}
				if(this.formData.rePass !=this.formData.pass) {
					uni.showToast({
						icon:'none',
						title:'两次密码不一致'
					})
					return ;
				}
				if(!this.checked) {
					uni.showToast({
						icon:'none',
						title:'请先阅读服务协议与隐私政策，并同意注册'
					})
					return ;
				}
				uni.showLoading()
				this.$api.sendRequest({
				    url: '/register',
					header:{
						'Content-Type':'application/json'
					},
				    data: {
						telephone:this.formData.phone,
						code:this.formData.code,
						password:aesEncrypt.encrypt(this.formData.rePass)
					},
				    success: res => {
						uni.hideLoading()
				        if(res.code && res.code==200){
							uni.redirectTo({
								url:'./login'
							})
				        }else{
				            uni.showModal({
				            	showCancel:false,
				                content:res.message
				            })
				            this.acquire = "验证码"
				            this.getCodeisWaiting = false;
				            clearInterval(this.Timer);
				            return
				        }
				    }
				});
			}
        }
    }
</script>

<style lang="scss" scoped>
	.container {
		padding-top: 100upx;
	}
   .logo {
	   width: 176upx;
	   height: 176upx;
	   margin: 0 auto 105upx;
	   image {
		   width: 100%;
		   height: 100%;
	   }
   }
   .input {
	    position: relative;
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 555upx;
		box-sizing: border-box;
		padding: 0 15upx 14upx;
		margin: 40upx auto;
		border-bottom: 2upx solid #DDDDDD;
		.img {
			display: block;
			width: 29upx;
			height: 46upx;
		}
		.xmg {
			display: block;
			width: 47upx;
			height: 43upx;
		}
		.uniInput {
			width: calc(100% - 60upx);
			font-size: 30upx;
			color: #333;
		}
		.vscode {
			position: absolute;
			right: 0;
			top: 0;
			width: 169upx;
			height: 45upx;
			line-height: 45upx;
			text-align: center;
			font-size: 22upx;
			font-weight: 400;
			color: #FFFFFF;
			background: #EB0000;
			border-radius: 10upx;
		}
   }
   .r_l {
	   width: 555upx;
	   display: flex;
	   justify-content: space-between;
	   margin: 25upx auto;
	   text {
		   font-size: 29upx;
		   font-weight: 400;
		   color: #151515;
	   }
   }
   .save {
		width: 555upx;
		height: 90upx;
		line-height: 90upx;
		text-align: center;
		margin:60upx auto 0;
		font-size: 38upx;
		font-weight: 400;
		color: #FFFFFF;
		background: #EB0000;
		border-radius: 10upx;
   }
   .secrity {
	   width: 555upx;
	   margin: 30upx auto;
	   font-size: 22upx;
	   font-weight: 400;
	   color: #939393;
	   .txt {
		   color: #EB0000;
	   }
   }
</style>

