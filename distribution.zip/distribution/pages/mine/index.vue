<template>
    <view>
		<!-- 导航站位 -->
        <view class="status_bar"></view>
		<view class="user">
			<view class="img" @tap="uploadPic">
			    <image class="avator" :src="user.avatar?$imgUrl + user.avatar : '/static/images/test/avator.png'" mode="aspectFill"></image>
				<view class="grade">
					<image class="v" src="/static/images/grade.png"></image>
					<text class="txt">黄金</text>
				</view>
			</view>
			<view class="u-nick">
				<view class="nickname">
					{{user.username}}	
				</view>
				<view class="u-ID">
					ID：{{user.inviteCode}}
				</view>
				<view class="referrer">
					推荐人：唯美
				</view>
			</view>
			<view class="isIden" v-if="user.authentication">
				已认证
			</view>
			<view class="noIden" v-else @tap="isLogin('attestation',0)">
				去认证
			</view>
		</view>
		<view class="cater">
			<view class="cater-item">
				<view class="title">
					累计收益
				</view>
				<view class="num">
					<text class="icon">￥</text>{{userMoney.cumulativeAcount || 0}}
				</view>
			</view>
			<view class="line"></view>
			<view class="cater-item">
				<view class="title">
					今日收益
				</view>
				<view class="num">
					<text class="icon">￥</text>{{userMoney.todayAcount || 0}}
				</view>
			</view>
			<view class="line"></view>
			<view class="cater-item">
				<view class="title">
					可提现
				</view>
				<view class="num">
					<text class="icon">￥</text>{{userMoney.canCarryAcount || 0}}
				</view>
			</view>
		</view>
		<view class="invalid">
			<view class="left" @tap="isLogin('./invite?inviteCode='+user.inviteCode,0)">
				<view class="in-item">
					<image class="invite" src="/static/images/test/invite.png" mode="aspectFill"></image>
					<view class="con">
						<view class="title">
							邀请码
						</view>
						<view class="qr">
							{{user.inviteCode}}
						</view>
					</view>
				</view>
			</view>
			<view class="right" @tap="isLogin('./withdraw/index',0)">
				<image class="deposit" src="/static/images/test/deposit.png"></image>
				<text>提现</text>
			</view>
		</view>
		<view class="mine-list">
			<view class="mine-item" v-for="(item,index) in mineList" :key="index" @tap="isLogin(item.url,index)">
				<view class="left">
					<image :src="item.img"></image>
					<text>{{item.title}}</text>
				</view>
				<view class="right">
					<image src="/static/images/arrow.png"></image>
				</view>
			</view>
		</view>
		<view class="quit btn">
			退出
		</view>
	</view>
</template>

<script>
    import {
        mapState,
        mapMutations
    } from 'vuex'
    export default {
        data () {
            return {
                call:'18153976759',
				user:'',
				userMoney:{},
				mineList:[
					{
						img:'/static/images/mine/1.png',
						title:'提现记录',
						url:'./withdraw/record'
					},
					{
						img:'/static/images/mine/2.png',
						title:'关于我们',
						url:'us'
					},
					{
						img:'/static/images/mine/3.png',
						title:'修改密码',
						url:'./editor/password'
					},
					{
						img:'/static/images/mine/4.png',
						title:'联系客服',
						url:''
					},
					{
						img:'/static/images/mine/5.png',
						title:'问题反馈',
						url:'feedbook'
					}
				]
            }
        },
        computed:{
            ...mapState(['hasLogin','userInfo'])
        },
        onLoad() {
			this.getUser ()
        },
		onShow() {
			this.getUserId ()
		},
        methods:{
            ...mapMutations(['login']),
            goLogin () {
                uni.navigateTo({
                    url:'login'
                })
            },
			getUser () {
				let that = this
				that.$api.sendRequest({
					method:'GET',
					url: '/user/'+that.userInfo.user.telephone,
					header: {
						'Content-Type': 'application/json',
						'Authentication': that.userInfo.token
					},
					data: {
					},
					success: res => {
						uni.hideLoading()
						that.user = res
						that.call = that.user.telephone
					}
				});
			},
			getUserId () {
				let that = this
				that.$api.sendRequest({
					method:'GET',
					url: '/earning/user-earning/getUserId',
					header: {
						'Content-Type': 'application/json',
						'Authentication': that.userInfo.token
					},
					data: {
					},
					success: res => {
						uni.hideLoading()
						that.userMoney = res
					}
				});
			},
			uploadPic () {
				let that = this
				uni.chooseImage({
				    count: 1, //默认9
				    sizeType: ['compressed'], //可以指定是原图还是压缩图，默认二者都有
				    success: (res) => {
						uni.showLoading()
						uni.uploadFile({
							url: that.$fileUrl + '/upload/img',
							filePath: res.tempFilePaths.shift(),
							fileType: 'image',
							name: "file",
							success: resc => {
								// 修改头像掉接口
								that.$api.sendRequest({
									url: '/user/avatar',
									// method: 'POST',
									header: {
										'Content-Type': 'application/json',
										'Authentication': that.userInfo.token
									},
									data: {
										telephone: that.userInfo.user.telephone,
										avatar: JSON.parse(resc.data).data
									},
									success: res2 => {
										uni.hideLoading()
										if (res2.code && res2.code == 200) {
											that.user.avatar = JSON.parse(resc.data).data 
											that.$forceUpdate()
										} else {
											// TODO 弹窗提示失败
										}
						
						
									}
								});
							}
						});
				    }
				});
			},
            isLogin (url,index) {
                let that = this
                if(index !=3){
                    if(!this.hasLogin) {
                        uni.showModal({
                            title: '提示',
                            content: '您还未登录，请先去登录',
                            success: function (res) {
                                if (res.confirm) {
                                    uni.navigateTo({
                                        url:'login'
                                    })
                                }
                            }
                        });
                    }else{
                        uni.navigateTo({
                            url:url
                        })
                    }
                }else{
                    uni.makePhoneCall({
                        phoneNumber: that.call //仅为示例
                    });
                }
            }
        }
    }
</script>

<style lang="scss" scoped>
	@mixin text-over {
		width: 100%;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
	.status_bar {  
	    width: 100%;
	    height: 110upx;
	    background-color: #EB0000;  
	} 
	.user {
		display: flex;
		justify-content: space-between;
		width: 100%;
		height: 260upx;
		box-sizing: border-box;
		padding: 0 32upx;
		background-color: #EB0000; 
		.img {
			position: relative;
			width: 160upx;
			height: 160upx;
			overflow: hidden;
			border: 10upx solid #F2C719;
			border-radius: 50%;
			.avator {
				display: block;
				width: 100%;
				height: 100%;
				border-radius: 50%;
			}
			.grade {
				position: absolute;
				bottom: 0upx;
				width: 100%;
				height: 60upx;
				line-height: 40upx;
				background: rgba($color: #000000, $alpha: .2);
				// opacity: 0.2;
				z-index: 1;
				text-align: center;
				.v {
					width: 20upx;
					height: 20upx;
					margin-right: 10upx;
					vertical-align: middle;
				}
				.txt {
					font-size: 22upx;
					font-weight: 400;
					color: #FFFFFF;
					vertical-align: middle;
				}
			}
		}
		.u-nick {
			width: calc(100% - 340upx);
			box-sizing: border-box;
			padding: 12upx 0;
			.nickname {
				@include text-over;
				font-size: 32upx;
				font-weight: 400;
				color: #FFFFFF;
			}
			.u-ID {
				@include text-over;
				margin-top: 5upx;
				font-size: 22upx;
				font-weight: 400;
				color: #FFFFFF;
			}
			.referrer {
				width: 208upx;
				height: 45upx;
				line-height:45upx;
				text-align: center;
				margin-top: 15upx;
				font-size: 22upx;
				font-weight: 400;
				color: #FFFFFF;
				box-shadow: 0 0 15upx #AF0303 inset;
				background: #CE0404;
				border-radius: 7upx;
			}
		}
		.isIden,.noIden {
			width: 111upx;
			height: 42upx;
			line-height: 42upx;
			margin-top: 15upx;
			text-align: center;
			font-size: 26upx;
			font-weight: 400;
			color: #EB0000;
			background-color: #FFFFFF;
			border-radius: 6upx;
		}
		.noIden {
			color: #fff;
			background-color: #dccaca;
		}
	}
	.cater {
		position: relative;
		top: -50upx;
		z-index: 10;
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 708upx;
		height: 173upx;
		margin: auto;
		background: #FFFFFF;
		border-radius: 10upx;
		border: 2upx solid #E2E2E2;
		box-shadow: 3upx 0upx 15upx #E2E2E2;
		.cater-item {
			width: calc(50% - 25upx);
			text-align: center;
			.num {
				margin-top: 15upx;
				font-size: 33upx;
				font-weight: 400;
				color: #EB0000;
				.icon {
					font-size: 29upx;
				}
			}
			.title {
				margin-top: 10upx;
				font-size: 22upx;
				font-weight: 400;
				color: #939393;
			}
		}
		.line {
			width: 1upx;
			height: 125upx;
			margin: 0 10upx;
			background: #DDDDDD;
			border-radius: 1upx;
		}
	}
	.invalid {
		display: flex;
		justify-content: space-between;
		width: 100%;
		box-sizing: border-box;
		padding: 28upx 73upx;
		margin-top: -30upx;
		.left,.right {
			width: 250upx;
			height: 111upx;
			box-sizing: border-box;
			border-radius: 10upx;
		}
		.left {
			padding: 20upx 30upx;
			background: linear-gradient(90deg, #00FFFC, #0042FF);
			.in-item {
				display: flex;
				justify-content: space-between;
				align-items: center;
				width: 100%;
				.invite {
					display: block;
					width: 70upx;
					height: 70upx;
					margin-right: 14upx;
				}
				.con {
					font-weight: 400;
					color: #FFFFFF;
					.title {
						font-size: 29upx;
					}
					.qr {
						font-size: 22upx;
					}
				}
			}
			
		}
		.right {
			text-align: center;
			line-height: 111upx;
			background: linear-gradient(90deg, #FBC430, #EB0000);
			.deposit {
				width: 72upx;
				height: 72upx;
				margin-right: 20upx;
				vertical-align: middle;
			}
			text {
				font-size: 29upx;
				font-weight: 400;
				color: #FFFFFF;
			}
		}
	}
	.mine-list {
		width: 100%;
		box-sizing: border-box;
		padding: 0 21upx;
		border-top: 34upx solid #F6F6F6;
		.mine-item {
			display: flex;
			justify-content: space-between;
			align-items: center;
			width: 100%;
			box-sizing: border-box;
			padding: 21upx 24upx;
			border-bottom: 2upx solid #DDDDDD;
			.left {
				image {
					width: 56upx;
					height: 49upx;
					margin-right: 20upx;
					vertical-align: middle;
				}
				text {
					font-size: 26upx;
					font-weight: 400;
					color: #000000;
					vertical-align: middle;
				}
			}
			.right {
				width: 15upx;
				height: 23upx;
				image {
					display: block;
					width: 100%;
					height: 100%;
				}
			}
		}
	}
	.quit {
		width: 556upx;
		height: 63upx;
		line-height: 63upx;
		text-align: center;
		font-size: 26upx;
		font-weight: 400;
		color: #FFFFFF;
		margin:30upx auto;
		background: #EB0000;
		border-radius: 10upx;
	}
</style>
