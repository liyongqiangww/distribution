<template>
    <view>
        <view class="bloom">
            <image src="/static/images/bg.png" mode=""></image>
        </view>
        <view class="floor-list">
            <view class="scroll-view-item" v-for="(item,index) in list" :key="index" @tap="newDetail(item.id,'dongtai')">
                <view class="img">
                    <image :src="item.litpic" mode="aspectFill"></image>
                </view>
                <view class="fatitle">
                    {{item.title}}
                </view>
            </view>
        </view>
        <uni-load-more iconType="snow" :status="status" v-if="showTip"/>
        <view class="nodata" v-else>
            暂无数据
        </view>
    </view>
</template>

<script>
    export default {
        data () {
            return {
                showTip:true,
                status: 'loading',//数据加载的状态(more：加载前,loading:加载中,noMore:没有更多)
                page:1,//上拉加载
                list:[],
            }
        },
        //上拉加载，需要自己在page.json文件中配置"onReachBottomDistance"
        onReachBottom() { 
            this.status = 'loading'
            this.page++;
        	this.getList(this.page);
        },
        onLoad() {
            this.getList(this.page)
        },
        methods:{
            newDetail (id,tablename) {
               uni.navigateTo({
                   url:`detail?id=${id}&tablename=${tablename}`
               })
            },
            getList(page){
                this.$api.sendRequest({
                	url: '/api/article/dongtai_list',
                	data: {
                        page:page
                	},
                	success: res => {
                		if(res.code && res.code == 200){
                		   this.list = this.list.concat(res.result)
                		   if(this.list.length == 0) {
                		       this.showTip = false
                		       return ;
                		   }
                		   if (res.result.length<15) {
                		       this.status = 'noMore'
                		   }else{
                		       this.status = 'more'
                		   }
                		}
                	}
                });
            }
        }
    }
</script>

<style lang="scss" scoped>
    .floor-list {
        width: 100%;
        display: flex;
        justify-content: flex-start;
        flex-wrap: wrap;
        padding-top: 20upx;
        .scroll-view-item {
            position: relative;
            display: inline-block;
            width: 50%;
            overflow: hidden;
            box-sizing: border-box;
            padding: 0 10upx;
            margin-bottom: 30upx;
            border-radius: 10upx;
            box-shadow:0 0 5upx 0 #dbdede;
            .img {
                width: 100%;
                height: 250upx;
                image {
                    width: 100%;
                    height: 100%;
                }
            }
            .fatitle {
                position: absolute;
                bottom: 0;
                left: 0;
                right: 0;
                width: calc(100% - 20upx);
                box-sizing: border-box;
                overflow: hidden;
                margin: auto;
                text-overflow: ellipsis;
                white-space: nowrap;
                padding:15upx 10upx;
                font-weight: bold;
                font-size: 32upx;
                color: #fff;
                background-color: rgba(0,0,0,.3);
                z-index: 10;
            }
        }
    }
</style>
