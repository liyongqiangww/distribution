<template>
	<view class="container">
		<view class="search">
			<view class="item">
				<image src="/static/images/search.png" mode=""></image>
				<text>请输入商品名称</text>
			</view>
		</view>
		<view class="wrap">
			<view class="swiperImg">
				<bw-swiper imageKey="path" :swiperList="imgArr" :swiperType="false" :autoplay="true" indicatorColor="#E6E6E6" indicatorActiveColor="#8E5EEE" :indicatorDots="false" style="width:100%"></bw-swiper>
			</view>
		</view>
		<view class="list">
			<view class="list-item" v-for="(item,index) in list" :key="index">
				<view class="left">
					<image src="/static/images/test/jd.png" mode="aspectFill"></image>
				</view>
				<view class="middle">
					<view class="title">
						{{item.name}}
					</view>
					<view class="descrip">
						项目编号{{item.projectId}}
					</view>
					<view class="syboml">
						<text @tap="toVideo(item.videoSrc)">视频教程</text>
						<text @tap="toPlat(item.platformRequest)">平台要求</text>
					</view>
				</view>
				<view class="right">
					<view class="price">
						￥<text class="num">{{item.projectAmount}}</text>
					</view>
					<view class="promotion btn" @tap.stop="toJump(item)">
						推广码
					</view>
				</view>
			</view>
		</view>
		<uni-load-more iconType="snow" :status="status" v-if="showTip"/>
		<view class="nodata" v-else>
		    暂无数据
		</view>
		<view class="tanVideo" v-show="videoShow" @tap="videoShow = false">
			<view class="videoShow" @tap.stop="">
				<video :autoplay="true" :src="videoUrl" controls="true"></video>
			</view>
		</view>
    </view>
</template>

<script>
    import {
        mapState,
        mapMutations
    } from 'vuex'
    import bwSwiper from '@/components/bw-swiper/wxcomponents/bw-swiper/bw-swiper.vue';
	export default {
		data() {
			return {
                imgArr:[
				],
				list:[],
				showTip:true,
				status: 'loading',//数据加载的状态(more：加载前,loading:加载中,noMore:没有更多)
				page:1,//上拉加载
				videoUrl:'',
				videoShow:false
			}
		},
		computed:{
		    ...mapState(['hasLogin','userInfo'])
		},
        components: { bwSwiper },
		onLoad() {
            // 隐藏原生分享按钮
            // uni.hideShareMenu()
			this.getBanner ()
			this.getList(this.page)
		},
        //上拉加载，需要自己在page.json文件中配置"onReachBottomDistance"
        onReachBottom() { 
            this.page++;
        	this.getList(this.page);
        },
		methods: {
            ...mapMutations(['setInfo']),
            toJump (item) {
				uni.navigateTo({
					url:'./tuiguang?item='+encodeURIComponent(JSON.stringify(item))
				})
			},
			toPlat (content) {
				uni.navigateTo({
					url:'./platform?content='+encodeURIComponent(JSON.stringify(content))
				})
			},
			toVideo (url) {
				this.videoUrl = this.$imgUrl + url
				this.videoShow = true
			},
			getBanner () {
				let that = this
				that.imgArr = []
				that.$api.sendRequest({
					method:'GET',
				    url: '/banner/getList',
					header:{
						// 'Content-Type':'application/json',
						'Authentication':that.userInfo.token
					},
				    data: {},
				    success: res => {
				        uni.hideLoading()
				        for(let s of res.data) {
						   that.imgArr.push({path:that.$imgUrl + s.src})
				        }
						
				    }
				});
			},
            getList (page) {
				let that = this
                this.$api.sendRequest({
					method:'GET',
                	url: '/project/getAll',
					header:{
						// 'Content-Type':'application/json',
						'Authentication':that.userInfo.token
					},
                	success: res => {
                		// this.list = this.list.concat(res.data)
						this.list = res
						this.status = 'noMore'
                		// if(this.list.length == 0) {
                		// 	this.showTip = false
                		// 	return ;
                		// }
                		// if (res.data.length<15) {
                		// 	this.status = 'noMore'
                		// }else{
                		// 	this.status = 'more'
                		// }
                	}
                });
            },
		}
	}
</script>

<style lang="scss">
    //多行文本省略
    @mixin n-ellipsis($n) {
    	overflow: hidden;
    	display: -webkit-box;
    	-webkit-line-clamp: $n;
    	-webkit-box-orient: vertical;
    	text-overflow: ellipsis;
    	word-break: break-all;
    }
    @mixin text-over {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
	.tanVideo {
		position: fixed;
		left: 0;
		top: 0;
		z-index: 10;
		width: 100%;
		height: 100%;
		background-color: rgba($color: #000000, $alpha: .6);
		.videoShow {
			position: absolute;
			top: 0;
			left: 0;
			bottom: 0;
			right: 0;
			width: 100%;
			height: 230px;
			box-sizing: border-box;
			padding: 0 32upx;
			margin: auto;
			video {
				width: 100%;
				height: 100%;
			}
		}
	}
	.search {
		position: fixed;
		top: 0upx;
		left: 0upx;
		z-index: 99;
		width: 100%;
		box-sizing: border-box;
		padding: 30upx 28upx;
		background-color: #EB0000;
		.item {
			display: flex;
			justify-content: flex-start;
			align-items: center;
			width: 100%;
			height: 63upx;
			box-sizing: border-box;
			padding: 14upx;
			background: #F47373;
			border-radius: 31upx;
			image {
				display: block;
				width: 34upx;
				height: 34upx;
				margin-right: 21upx;
			}
			text {
				font-size: 26upx;
				font-weight: 400;
				color: #FFFFFF;
			}
		}
	}
	.wrap {
		width: 100%;
		height: 260upx;
		box-sizing: border-box;
		padding:90upx 28upx;
		background-color: #EB0000;
		.swiperImg {
			width: 100%;
			height: 312upx;
			overflow: hidden;
			border-radius: 28upx;
			margin-top: 38upx;
		}	
	}
	.list {
		width: 100%;
		box-sizing: border-box;
		padding: 0 21upx;
		margin-top: 220upx;
		.list-item {
			display: flex;
			justify-content: flex-start;
			align-items: center;
			width: 100%;
			box-sizing: border-box;
			padding:21upx 38upx;
			margin-bottom: 25upx;
			border-radius: 10upx;
			border: 2upx solid #E3E3E3;
			box-shadow: 0upx 0upx 15upx #E3E3E3;
			.left {
				width: 119upx;
				height: 119upx;
				margin-right: 38upx;
				image {
					width: 100%;
					height: 100%;
					border-radius: 20upx;
				}
			}
			.middle {
				width: 260upx;
				.title {
					@include text-over;
					font-size: 29upx;
					font-weight: 400;
					color: #000000;
				}
				.descrip {
					@include text-over;
					font-size: 22upx;
					font-weight: 400;
					color: #939393;
				}
				.syboml {
					margin-top: 5upx;
					text {
						margin-right: 15upx;
						font-size: 22upx;
						font-weight: 400;
						color: #EB0000;
					}
				}
			}
			.right {
				// text-align: center;
				margin-left: 90upx;
				.price {
					font-size: 22upx;
					font-weight: 400;
					color: #EB0000;
					.num {
						font-size: 49upx;
						font-weight: bold;
					}
				}
				.promotion {
					width: 117upx;
					height: 45upx;
					line-height: 45upx;
					text-align: center;
					margin-top: 10upx;
					font-size: 22upx;
					font-weight: 400;
					color: #FFFFFF;
					background: #EB0000;
					border-radius: 6upx;
				}
			}
		}
	}
</style>
