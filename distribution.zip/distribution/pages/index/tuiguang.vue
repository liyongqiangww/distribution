<template>
	<view>
		<view class="container">
			<view class="title">
				申请流程：
			</view>
			<view class="flow" v-html="flowItem"></view>
			<view class="tip">
				{{tip}}
			</view>
		</view>
		<view class="form">
			<view class="form_item" v-for="(item,index) in resouceList" :key="index">
				<view class="input" v-if="item.type == 'input'">
					<text class="txt">{{item.title}}<text class="sybol">*</text></text>
					<input class="uniInput" v-model="item.value" :placeholder="'请输入'+item.title" placeholder-style="fotn-size:30upx;color: #939393;"/>
				</view>
				<picker v-if="item.type == 'select'&&item.province==1" @change="pChange($event,index)" :value="pIndex" :range="province">
					<view class="input">
						<text class="txt">{{item.title}}<text class="sybol">*</text></text>
						<input class="uniInput" v-model="province[pIndex]" placeholder="选择省/市>" placeholder-style="fotn-size:30upx;color: #939393;"/>
					</view>
				</picker>
				<picker v-if="item.type == 'select'&&item.city==1" @change="cChange($event,index)" :value="cIndex" :range="city">
					<view class="input">
						<text class="txt">{{item.title}}<text class="sybol">*</text></text>
						<input class="uniInput" v-model="city[cIndex]"  placeholder="选择市/区>" placeholder-style="fotn-size:30upx;color: #939393;"/>
					</view>
				</picker>
				<picker v-if="item.type == 'check'" @change="dChange($event,index)" :value="dIndex" :range="isTui">
					<view class="input">
						<text class="txt">{{item.title}}<text class="sybol">*</text></text>
						<input class="uniInput" disabled v-model="isTui[dIndex]" placeholder="请选择>" placeholder-style="fotn-size:30upx;color: #939393;"/>
					</view>
				</picker>
			</view>
			
			<view class="save btn" @tap="save">
				提交
			</view>
		</view>
	</view>
</template>

<script>
	import {
	    mapState,
	    mapMutations
	} from 'vuex'
	import areaData from '@/js_sdk/areaData.js';
	export default {
		data (){
			return {
				name:'',
				tId:'',
				card:'',
				pIndex:-1,
				province:[],
				cIndex:-1,
				city:[],
				flowItem:'',
				tip:'',
				dIndex:0,
				isTui:['否','是'],
				cj:'',
				lp:'',
				remark:'',
				project_item:{},
				resouceList:[]
			}
		},
		computed:{
		    ...mapState(['hasLogin','userInfo'])
		},
		onLoad(option) {
			let that = this
			const item = JSON.parse(decodeURIComponent(option.item));
			this.project_item = item
			this.flowItem = item.platformRequest
			this.tip = item.operationProcess
			this.resouceList = item.resouceList
			for(let i=0;i<this.resouceList.length;i++) {
				this.resouceList[i].value = ''
				if(this.resouceList[i].name == 'provincial_address')
				this.resouceList[i].province = 1
				if(this.resouceList[i].name == 'city_address')
				this.resouceList[i].city = 1
			}
			that.province = []
			areaData.forEach(function (element, index) {
			    that.province.push(element.name)
			})
		},
		methods:{
			dChange (e,sindex) {
				this.dIndex = e.detail.value
				this.resouceList[sindex].value = this.isTui[this.dIndex]
			},
			pChange (e,sindex) {
				let index = 0,that=this
				this.city = []
				this.pIndex = e.detail.value
				this.cIndex = -1
				this.resouceList[sindex].value = this.province[this.pIndex]
				index = this.province.findIndex(item => item == this.province[this.pIndex])
				let arr = areaData[index].child
				arr.forEach(function (element, index) {
				    that.city.push(element.name)
				})
				
			},
			cChange (e,sindex) {
				this.cIndex = e.detail.value 
				for(let i=0;i<this.resouceList.length;i++){
					if(this.resouceList[sindex].city==1){
						this.resouceList[sindex].value = this.city[this.cIndex]
					}
				}
			},
			getCity(){
				
			},
			save () {
				let that = this
				// let phones=/^1(3|4|5|6|7|8|9)\d{9}$/,identy=/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
				// if(!this.name) {
				// 	uni.showToast({
				// 		icon:'none',
				// 		title:'请输入真实姓名'
				// 	})
				// 	return ;
				// }
				// if(!this.tId) {
				// 	uni.showToast({
				// 		icon:'none',
				// 		title:'请输入淘宝ID'
				// 	})
				// 	return ;
				// }
				// if(!(identy.test(this.card))){
				// 	uni.showToast({ title: '请输入正确的身份证号', icon: "none" });
				// 	return false; 
				// } 
				// if(this.pIndex == -1){
				// 	uni.showToast({ title: '请选择省', icon: "none" });
				// 	return false; 
				// } 
				// if(this.cIndex == -1){
				// 	uni.showToast({ title: '请选择市', icon: "none" });
				// 	return false; 
				// } 
				// if(!this.cj){
				// 	uni.showToast({ title: '请输入推广场景', icon: "none" });
				// 	return false; 
				// } 
				// if(!this.lp){
				// 	uni.showToast({ title: '请输入推广礼品', icon: "none" });
				// 	return false; 
				// }
				// if(!this.remark){
				// 	uni.showToast({ title: '请输入备注', icon: "none" });
				// 	return false; 
				// }
				
				uni.showLoading()
				that.$api.sendRequest({
				    url: '/project/project-user/save',
					header:{
						'Content-Type':'application/json',
						'Authentication':that.userInfo.token
					},
				    data: {
						userTelephone:that.userInfo.user.telephone,
						projectId:that.project_item.projectId,
						promoteCode:JSON.stringify(that.project_item.resouceList)
					},
				    success: res => {
				        uni.hideLoading()
						if(res.code && res.code==200){
							uni.switchTab({
								url:'/pages/index/index'
							})
						}else{
							uni.showModal({
								showCancel:false,
							    content:res.message
							})
						}
				    }
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		width: 100%;
		box-sizing: border-box;
		padding: 34upx 21upx;
		.title {
			font-size: 34upx;
			font-weight: bold;
			color: #151515;
		}
		.flow {
			margin-top: 10upx;
			font-size: 22upx;
			font-weight: 400;
			color: #464545;
		}
		.tip {
			text-indent: 45upx;
			margin-top: 30upx;
			font-size: 22upx;
			font-weight: 400;
			color: #EB0000;
		}
	}
	.form {
		width: 100%;
		box-sizing: border-box;
		padding: 0 21upx;
		background-color: #fff;
		border-top: 35upx solid #F6F6F6;
		.form_item {
			.input {
				position: relative;
				display: flex;
				justify-content: space-between;
				align-items: center;
				width: 100%;
				box-sizing: border-box;
				padding: 0 15upx 14upx;
				margin: 40upx auto;
				border-bottom: 2upx solid #DDDDDD;
				.txt {
					font-size: 26upx;
					font-weight: 400;
					color: #151515;
					.sybol {
						color: #EB0000;
					}
				}
				.uniInput {
					width: calc(100% - 160upx);
					font-size: 30upx;
					color: #333;
				}
				
			}
		}
		
		.save {
			width: 555upx;
			height: 90upx;
			line-height: 90upx;
			text-align: center;
			margin:50upx auto 0;
			font-size: 38upx;
			font-weight: 400;
			color: #FFFFFF;
			background: #EB0000;
			border-radius: 10upx;
		}
	}
</style>
