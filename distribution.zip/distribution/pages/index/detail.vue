<template>
    <view>
        <view class="bloom">
            <image src="/static/images/bg.png" mode=""></image>
        </view>
        <view class="article">
            <view class="title">
                {{detail.title ||''}}
            </view>
            <view class="glance">
                <image class="eye" src="/static/images/eyes.png" mode=""></image>
                <text>{{detail.readcount || 0}}</text>
                <image class="time" src="/static/images/time.png" mode=""></image>
                <text>{{detail.add_time || ''}}</text>
            </view>
            <view class="content" v-html="content"></view>
        </view>
    </view>
</template>

<script>
    export default {
        data () {
            return {
                detail:{},
                content:''
            }
        },
        onLoad(option) {
           this.getDetail (option.id,option.tablename)  
        },
        methods: {
            getDetail (id,tablename) {
                this.$api.sendRequest({
                	url: '/api/article/details',
                	data: {id:id,tablename:tablename},
                	success: res => {
                		if(res.code && res.code == 200){
                           this.detail = res.result
                		   var richtext =  res.result.content;
                		   const regex = new RegExp('<img', 'gi');
                		   // 判断是否头图片
                		   if(richtext.indexOf('img') != -1){
                		       richtext= richtext.replace(regex, `<img style="width: 100%;border-radius:5px"`);
                		   }
                		   this.content = richtext;
                		}
                	}
                });
            }
        }
    }
</script>

<style lang="scss">
    .article {
        width: 100%;
        box-sizing: border-box;
        padding: 0 32upx;
        border-top: 2upx solid #F2F4FA;
        .title {
            margin-top: 30upx;
            color: #333;
            font-size: 32upx;
            font-weight: bold;
        }
        .glance {
            width: 100%;
            padding: 30upx 0;
            border-bottom: 2upx solid #EDEFF5;
            .eye {
                width: 32upx;
                height: 30upx;
                vertical-align: middle;
            }
            .time {
                width: 25upx;
                height: 25upx;
                margin-left: 48upx;
                vertical-align: middle;
            }
            text {
                font-size: 26upx;
                color: #999;
                margin-left: 13upx;
                vertical-align: middle;
            }
        }
        .content {
            width: 100%;
            line-height: 50upx;
            margin-top: 30upx;
            font-size: 30upx;
        }
    }
</style>
