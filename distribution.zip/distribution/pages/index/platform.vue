<template>
    <view>
        <view class="article">
            <view class="content" v-html="content"></view>
        </view>
    </view>
</template>

<script>
    export default {
        data () {
            return {
                detail:{},
                content:''
            }
        },
        onLoad(option) {
           this.content = JSON.parse(decodeURIComponent(option.content));
        },
        methods: {
            
        }
    }
</script>

<style lang="scss">
    .article {
        width: 100%;
        box-sizing: border-box;
        padding: 0 32upx;
        border-top: 2upx solid #F2F4FA;
        .title {
            margin-top: 30upx;
            color: #333;
            font-size: 32upx;
            font-weight: bold;
        }
        .glance {
            width: 100%;
            padding: 30upx 0;
            border-bottom: 2upx solid #EDEFF5;
            .eye {
                width: 32upx;
                height: 30upx;
                vertical-align: middle;
            }
            .time {
                width: 25upx;
                height: 25upx;
                margin-left: 48upx;
                vertical-align: middle;
            }
            text {
                font-size: 26upx;
                color: #999;
                margin-left: 13upx;
                vertical-align: middle;
            }
        }
        .content {
            width: 100%;
            line-height: 50upx;
            margin-top: 30upx;
            font-size: 30upx;
        }
    }
</style>
