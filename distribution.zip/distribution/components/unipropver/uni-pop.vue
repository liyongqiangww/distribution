<template>
    <view>
        <view class="popx" v-show="poup" @tap="poup=false">
            <view class="popbg">
                <image src="/static/images/nodata.png" mode=""></image>
                <view class="perfect">
                    请先完善个人资料!
                </view>
                <view class="preBtn" @tap.stop="goInfo">
                    去完善
                </view>
            </view>
        </view>
    </view>
</template>

<script>
    export default {
        name:'uni-pop',
        data () {
            return {
                poup:false
            }
        },
        methods:{
            open (){
                this.poup = true
            },
            close(){
                this.poup = false
            },
            goInfo () {
                this.poup = false
                uni.navigateTo({
                    url:'/pages/mine/info'
                })
            }
        }
    }
</script>

<style lang="scss">
    .popx {
        position: fixed;
        width: 100%;
        height: 100%;
        left: 0;
        top: 0;
        z-index: 9999;
        background-color: rgba($color: #000000, $alpha: .44);
        .popbg {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: 503upx;
            height: 513upx;
            box-sizing: border-box;
            padding: 26upx 60upx 0;
            margin: auto;
            background: #FFFFFF;
            border-radius: 12upx;
            image {
                width: 388upx;
                height: 270upx;
            }
            .perfect {
                width: 100%;
                text-align: center;
                font-size: 32upx;
                color: #333;
                margin-top: 10upx;
            }
            .preBtn {
                width: 318upx;
                height: 80upx;
                line-height: 80upx;
                text-align: center;
                font-size: 30upx;
                color: #fff;
                margin: 30upx auto 0;
                background: linear-gradient(-90deg, #5E3ECF, #9B67FB);
                box-shadow: 0px 0px 20upx 0px rgba(155, 103, 251, 0.79);
                border-radius: 40upx;
            }
        }
    }
</style>
