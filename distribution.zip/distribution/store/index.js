import Vue from 'vue'
import Vuex from 'vuex'
import AES from '../common/aes.js'
Vue.use(Vuex)

const store = new Vuex.Store({
    state: {
        /**
         * 是否需要强制登录
         */
        forcedLogin: false,
        hasLogin: false,
        perfect:false,
        userInfo: {}
    },
    mutations: {
        setInfo (state) {
            state.perfect = true
        },
        login(state, userInfo) {
            state.userInfo = userInfo || '新用户';
            state.hasLogin = true;
            // 加密
            let encrypt = AES.AES.encrypt(JSON.stringify(state.userInfo),'Ow8bd11KeZS=','123456')
            uni.setStorage({
                key: 'userInfo',
                data: encrypt,
                success: function () {
                    console.log('success');
                }
            });
        },
        logout(state) {
            state.userInfo = {};
            state.hasLogin = false;
            state.perfect = false
            uni.removeStorage({
                key: 'userInfo'
            })
            uni.reLaunch({
                url:'/pages/index/index'
            })
        }
    }
})

export default store
